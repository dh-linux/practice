from pyzabbix import zabbixapi
import json


url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_graph(templateid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.graph.get(
            {
                "output": "extend",
                "hostids": "%s" % templateid,
                "sortfield": "name"
            })

    return response.text
    print json.dumps(json.loads(response.text),indent=2)
    
def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.template.get(
            {
                "output": "extend",
                "filter": {
                    "host":["%s" % template_name]
                }
            })

    print json.dumps(json.loads(response.text),indent=2)
    return json.loads(response.text)["result"][0]["templateid"]
def add_screen(graphids,screenid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    for y in range(len(graphids)/2):
        for x in range(2):
            response=zb.screenitem.create(
                    {
                        "screenid":screenid,
                        "resourcetype": 0,
                        "resourceid":graphids[2*y+1*x],
                        "rowspan":1,
                        "colspan":1,
                        "width":900,
                        "x": x,
                        "y": y
                    })

            print json.dumps(json.loads(response.text),indent=2)

screenid="132"
template_name='Template Log Upload - httplog status Summary'
templateid=get_template_id(template_name)
rt=get_graph(templateid)
graphids_list=[]
for graph in json.loads(rt)["result"]:
    graphids_list.insert(0,graph['graphid'])
add_screen(graphids_list,screenid)
