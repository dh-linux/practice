from pyzabbix import zabbixapi
import string
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_action():
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.action.get(
            {
                "output":"extend",
                "selectOperations": "extend",
                "selectFilter": "extend",
            })
    print json.dumps(json.loads(response.text),indent=2)


get_action()
