#!/bin/bash 
sum=0
n=10
min=1000000000000
max=0
for((i=0;i<=$n;i++))
do
    result=`ab -n 10 -c 1 127.0.0.1/|grep "Time per request"|grep 'across'|awk '{print $4}'`
    sum=`echo $sum $result|awk '{sum=$1+$2;print sum}'`
    max_min=`echo $result $max $min|awk '{max=$2;min=$3;if($1>$2)max=$1;if($1<$3)min=$1; print max,min}'`
    max=`echo ${max_min}|awk '{print $1}'`
    min=`echo ${max_min}|awk '{print $2}'`
done
echo sum:$sum 
echo count:$n
echo $sum $n|awk '{print "avg:",$1/$2}'
echo "max:"$max
echo "min:"$min
