from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_hostid(host_name):

    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.host.get(
        {
            "output": "extend",
            "selectGroups": "extend",
            "filter": {
                "host": [
                    "%s" % host_name,
                ]
            }
        })
    if len(json.loads(response.text)["result"])==0:
        return -1
    else:
        return  json.loads(response.text)["result"][0]["hostid"]

def update_host(host_id,groupids):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    
    group_list=[]
    for id in groupids.split(","):
        group_list.append({"groupid":"%s" % id})

    response=zb.host.update(
            {
                "hostid": "%s" % host_id,
                "groups": group_list,
            })
    print json.dumps(json.loads(response.text),indent=2)




def get_groupid(group_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.hostgroup.get(
            {
            
                "output": "extend",
                "filter": {
                    "name": [
                        "%s" % group_name
                    ]
                }
            })
    return  json.loads(response.text)["result"][0]["groupid"]
    print json.dumps(json.loads(response.text),indent=2)
    
location_dict={
    "bx" :"Beijing",
    "gz" :"Guangzhou",
    "sx" :"Guangzhou",
    "yf" :"Beijing",
    "yz" :"Beijing",
    "hy" :"Tianjin",
    "xd" :"Beijing"
}
groups=["Sina Weibo UnistoreSvc","All Discovered hosts"]


with open("./host") as file_handle:
    while 1:
        line = file_handle.readline()
        if not line:
            break
        else:
            host_name=line.split()[0].strip()
            location=host_name.split('.')[3]
            hostid=get_hostid(host_name)
            groupids=""
            if int(hostid)!=-1:
                for group_name in groups:
                    groupids+=get_groupid(group_name.strip())+","
                groupids+=get_groupid(groups[0]+" "+location_dict[location])+","
                update_host(hostid,groupids[0:-1])
                print host_name,groupids
            else:
                print "#"*10,host_name
