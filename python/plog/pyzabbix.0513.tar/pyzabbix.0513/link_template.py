from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"

url="http://10.77.120.198/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"



def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def get_host_info(group_id):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    rt=zb.host.get(
            {
                "output": "extend",
                "selectGroups": "extend",
                "selectInterfaces":"extend",
                "selectParentTemplates": [
                    "templateid",
                    "name"
                ],
                "groupids":"%s" % group_id
            })
    return rt.text

def get_group_id(group_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    rt=zb.hostgroup.get(
            {
                "output": "extend",
                "filter": {
                    "name":["%s" % group_name]
                }
            })
    return json.loads(rt.text)["result"][0]["groupid"]
    print json.dumps(json.loads(rt.text),indent=2)

def add_template(host_info,templateid_list):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)


    hostid=host_info["hostid"]
    delete_list=[]

    if "parentTemplates" in host_info:
        for templates in host_info["parentTemplates"]:
            del templates["name"]
            delete_list.append(templates)

    print "delete_list",delete_list
    print "add list",templateid_list
    
    temp_delete_list=delete_list[:]
    temp_add_list=templateid_list[:]

    for template in temp_delete_list:
        print template
        if template in templateid_list:
            delete_list.remove(template)
            temp_add_list.remove(template)

    if len(delete_list)!=0:
        rt=zb.host.update(
            {
                "hostid":hostid,
                "templates_clear":delete_list
                
            })
        print json.dumps(json.loads(rt.text),indent=2)

    print "delete_list",delete_list
    print "add list",templateid_list
    
    if len(temp_add_list)!=0:
        rt=zb.host.update(
            {
                "hostid":hostid,
                "templates":templateid_list
                
            })
        print json.dumps(json.loads(rt.text),indent=2)

templates_list=[
    "Template App Zabbix Agent",
    "Template OS Filesystem Status",
    "Template OS HardWare raid",
    "Template OS Linux",
    "Template OS Network Status",
    "Template OS IO status",
    "Template Log storage - access log",
    "Template OS storage usage info",
]
templateid_list=[]

for template in templates_list:
    templateid=get_template_id(template)
    templateid_list.append({"templateid":templateid})

group_id=get_group_id("Sina Weibo Storage")
host_list=get_host_info(group_id)
for host in json.loads(host_list)["result"]:
    print host["hostid"],host["name"]
    add_template(host,templateid_list)
    import time
group_id=get_group_id("Sina Weibo NotFs")
host_list=get_host_info(group_id)
for host in json.loads(host_list)["result"]:
    print host["hostid"],host["name"]
    add_template(host,templateid_list)
    import time
