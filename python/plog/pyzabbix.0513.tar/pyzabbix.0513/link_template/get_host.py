from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"

url="http://10.77.120.198/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"



def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def get_host_info(group_id):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    if group_id is not None:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "groupids":"%s" % group_id
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text

def get_group_id(group_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    rt=zb.hostgroup.get(
            {
                "output": "extend",
                "filter": {
                    "name":["%s" % group_name]
                }
            })
    return json.loads(rt.text)["result"][0]["groupid"]
    print json.dumps(json.loads(rt.text),indent=2)

def add_template(host_info,templateid_list):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)


    hostid=host_info["hostid"]
    all_list=[]

    if "parentTemplates" in host_info:
        for templates in host_info["parentTemplates"]:
            del templates["name"]
            all_list.append(templates)

    if len(all_list)!=0:
        rt=zb.host.update(
            {
                "hostid":hostid,
                "templates":all_list
                
            })
        print json.dumps(json.loads(rt.text),indent=2)

host_list=get_host_info(group_id=None)
print json.dumps(json.loads(host_list),indent=2)
