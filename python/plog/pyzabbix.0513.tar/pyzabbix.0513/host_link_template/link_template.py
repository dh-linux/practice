from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"

url="http://10.77.120.198/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"



def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def get_host_info(host_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    rt=zb.host.get(
            {
                "output": "extend",
                "selectGroups": "extend",
                "selectInterfaces":"extend",
                "selectParentTemplates": [
                    "templateid",
                    "name"
                ],
                "filter":{
                    "host":["%s" % host_name]
                }
            })
    return rt.text

def get_group_id(group_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    rt=zb.hostgroup.get(
            {
                "output": "extend",
                "filter": {
                    "name":["%s" % group_name]
                }
            })
    return json.loads(rt.text)["result"][0]["groupid"]
    print json.dumps(json.loads(rt.text),indent=2)

def add_template(host_info,templateid_list):

    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)


    hostid=host_info["hostid"]
    all_list=[]

    if "parentTemplates" in host_info:
        for templates in host_info["parentTemplates"]:
            del templates["name"]
            all_list.append(templates)
    if len(templateid_list)!=0:
        all_list.extend(templateid_list)


    if len(all_list)!=0:
        rt=zb.host.update(
            {
                "hostid":hostid,
                "templates":all_list
                
            })
        print json.dumps(json.loads(rt.text),indent=2)


templates_list=["Template APP Nginx Stats"]
templateid_list=[]

for template in templates_list:
    templateid=get_template_id(template)
    templateid_list.append({"templateid":templateid})

with open("./host_list") as fp:
    while 1:
        line=fp.readline()
        if not line:
            break
        else:
            result=get_host_info(line.strip())
            host_list=json.loads(result)["result"]
            if len(host_list)!=0:
                host=host_list[0]
                print json.dumps(json.loads(result),indent=2)
                print host["hostid"],host["name"]
                add_template(host,templateid_list)
            else:
                print line.strip()
