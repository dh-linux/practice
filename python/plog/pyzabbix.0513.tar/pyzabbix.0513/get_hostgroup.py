from pyzabbix import zabbixapi
import string
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
'''
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
'''
def create_group(group_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.hostgroup.create(
            {
            
                "name": "%s" % group_name,
            })
    print json.dumps(json.loads(response.text),indent=2)

def host_create(host_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.host.create(
                {
                    "host": "%s" % host_name ,
                    "interfaces": [
                        {
                            "type": 1,
                            "main": 1,
                            "useip": 1,
                            "ip": "127.0.0.1",
                            "dns": "",
                            "port": "10050"
                        }
                    ],
                    "groups": [
                        {
                            "groupid": "6"
                        }
                    ]
                })
    print json.dumps(json.loads(response.text),indent=2)
with open("./host_group") as f:
    while 1:
        line=f.readline()
        if not line:
            break
        else:
            if line.startswith("Sina"):
                host_name=line.strip()
                host_create(host_name)
                create_group(host_name)
