from pyzabbix import zabbixapi
import string
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_templateid(template_name):
    url="http://10.210.71.145/zabbix/api_jsonrpc.php"
    user="admin"
    password="zabbix"
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":['Template Log Upload - httplog status']
                }
            })
    return json.loads(response.text)["result"][0]["templateid"]

def get_item(templateid):
    url="http://10.210.71.145/zabbix/api_jsonrpc.php"
    user="admin"
    password="zabbix"
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.item.get(
            {
                "output":"extend",
                "hostids": templateid,
            })
    for item in json.loads(response.text)["result"]:
        print item["key_"]

templateid=get_templateid("Template Log Upload - httplog status")
get_item(templateid)



