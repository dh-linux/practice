from pyzabbix import zabbixapi
import json


url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def add_item(hostid,item_file):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    with open(item_file) as file_handle:
        while 1:
            line = file_handle.readline()
            if not line:
                break
            else:

                key=line.strip()
                name=line.strip()
                name_str=" ".join((name.split("_")[0],"==",name[8:]))
                params={
                    "name": name_str,
                    "key_": key,
                    "hostid": hostid,
                    "type": 2,
                    "value_type": 3,
                    "interfaceid": "",
                    "delay": 60
                }
                response=zb.item.create(params)
                print json.dumps(json.loads(response.text),indent=2)
templateid=get_template_id("Template OS netstat")
add_item(templateid,"./item_list")
