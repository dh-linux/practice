from pyzabbix import zabbixapi
import json


url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
def get_key_id(hostids):

    item_dict={}
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.item.get(
            {
                "output": "extend",
                "hostids": "%s" % hostids,
            })
    for item in  json.loads(response.text)["result"]:
        key=item["key_"]
        item_id=item["itemid"]
        item_dict[key]=item_id

    return  item_dict

def add_graph(service,service_prefix,pic_type_file,response_code_file,time_type_file,item_dict,templateid):

    color_list=["33FF33","008800","CCCC00","FF3333","880000","CC00CC","0000BB"]
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    with open(response_code_file) as file_handle_1:

        id_list=[]
        key_list=[]

        while 1:
            response_code=file_handle_1.readline()
            if not response_code:
                break
            else:
                key=service_prefix+"_"+response_code.strip()
            key_list.append(key)
        
        gitems=[]
        for  i  in  range(0,len(key_list)):
            key=key_list[i]
            itemid=item_dict[key]
            color=color_list[i]
            if i==len(key_list):
                drawtype=0
                yaxisside=1
            else:
                drawtype=1
                yaxisside=0
            gitems.append(
                    {
                        "itemid":itemid,
                        "color":color,
                        "sortorder":i,
                        "drawtype":drawtype,
                        "yaxisside":yaxisside
                    }
            )
        name=service+" - "+"response code count"
        response=zb.graph.create(
                {
                    "name": name, 
                    "width": 900,
                    "height": 200,
                    "gitems":gitems
                })
        print json.dumps(json.loads(response.text),indent=2)
    with open(pic_type_file) as file_handle:
        while 1:
            pic_type=file_handle.readline()
            if not  pic_type:
                break 
            else:
                with open(response_code_file) as file_handle_1:

                    id_list=[]
                    key_list=[]

                    while 1:
                        response_code=file_handle_1.readline()
                        if not response_code:
                            break
                        else:
                            key=service_prefix+"_"+pic_type.strip()+"_"+response_code.strip()
                        key_list.append(key)
                    
                    gitems=[]
                    for  i  in  range(0,len(key_list)):
                        key=key_list[i]
                        itemid=item_dict[key]
                        color=color_list[i]
                        if i==4:
                            drawtype=0
                            yaxisside=1
                        else:
                            drawtype=1
                            yaxisside=0
                        gitems.append(
                                {
                                    "itemid":itemid,
                                    "color":color,
                                    "sortorder":i,
                                    "drawtype":drawtype,
                                    "yaxisside":yaxisside
                                }
                        )
                    name=service+" - /"+pic_type.strip()+"/ response code"
                    response=zb.graph.create(
                            {
                                "name": name, 
                                "width": 900,
                                "height": 200,
                                "gitems":gitems
                            })
                    print json.dumps(json.loads(response.text),indent=2)
def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.template.get(
            {
                "output": "extend",
                "filter": {
                    "host":["%s" % template_name]
                }
            })

    print json.dumps(json.loads(response.text),indent=2)
    return json.loads(response.text)["result"][0]["templateid"]

templateid=get_template_id("Template Log Icache - access log")
item_dict=get_key_id(templateid)
add_graph(
        "Icache",
        "icache",
        "./pic",
        "./rt",
        "./time_type",
        item_dict,
        templateid)
