from pyzabbix import zabbixapi
import json


url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
def update_graph(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.host.get(
            {
                "output":"extend",
                "templated_hosts":1,
                "interfaceid":1,
                "filter": 
                {
                    "name":"%s" % template_name
                }
            })
    hostid=json.loads(response.text)["result"][0]["hostid"]

    response=zb.graph.get(
            {
                "output":"extend",

                "hostids":hostid
            })
    
    for graph in json.loads(response.text)["result"]:
        print graph["name"]
template_name=[
    "Template Log Service - http access",
]
for  i in template_name:
    update_graph(i)
