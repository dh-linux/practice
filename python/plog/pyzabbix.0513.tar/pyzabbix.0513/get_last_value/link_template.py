from pyzabbix import zabbixapi
import json
import time

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"

url="http://10.77.120.198/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"




def get_host_info(group_id):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    if group_id is not None:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "groupids":"%s" % group_id
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text


def get_last_value(hostid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    rt=zb.item.get(
            {
                "output": "extend",
                "hostids": "%s" % hostid,
                "filter": {
                    "key_":["system.cpu.switches"]
                }
            })
    try:
        intervalue=time.time()-int(json.loads(rt.text)["result"][0]["lastclock"])-60*60*5
    except:
        intervalue=-100
    return intervalue

may_lost_host=[]
group_name=None
if group_name is None:
    host_list=get_host_info(group_id=None)
else:
    group_id=get_group_id(group_name)
    host_list=get_host_info(group_id)
for host in json.loads(host_list)["result"]:
    hostid=host["hostid"]
    hostname=host["name"]
    result=get_last_value(hostid)
    if result>0:
        may_lost_host.append(hostname)

for host in may_lost_host:
    print host
