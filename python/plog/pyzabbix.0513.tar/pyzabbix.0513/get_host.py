from pyzabbix import zabbixapi
import string
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
def get_host(proxyids):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    user="baoning1"
    password="1234qwer"
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.host.get(
            {
                "output":"extend",
                "selectGroups":"extend",
                "selectInterfaces":"extend",
                "proxyids":proxyids
            })
    return response.text

def get_group(group_name):
    url="http://10.210.71.145/zabbix/api_jsonrpc.php"
    user="admin"
    password="zabbix"
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.hostgroup.get(
            {
                "output":"extend",
                "filter":{
                    "name":[group_name]
                }
            })

    return json.loads(response.text)["result"][0]["groupid"]

def host_create(host_info,proxy_hostid):
    url="http://10.210.71.145/zabbix/api_jsonrpc.php"
    user="admin"
    password="zabbix"
    zb=zabbixapi(url=url,user=user,password=password)

    global group_list

    host_name=host_info["host"]
    
    
    interfaces=host_info["interfaces"]
    del interfaces[0]["interfaceid"]
    del interfaces[0]["hostid"]

    add_group=[]
    for group in  host_info["groups"]:
        if group["name"] in group_list.keys():
            group_name=group["name"]
            add_group.append({"groupid": group_list[group_name]})


    print host_name,interfaces,add_group
    response=zb.host.create(
                {
                    "host": "%s" % host_name ,
                    "interfaces": interfaces,
                    "proxy_hostid":proxy_hostid,
                    "groups":add_group
                })
    print json.dumps(json.loads(response.text),indent=2)

proxyids={
        "sysadmin001.weibo.imgbed.qxg.sinanode.com":"14686",
        "sysadmin001.weibo.imgbed.bx.sinanode.com":"15089",
        "zbx001.weibo.imgbed.hy.sinanode.com":"15091"}

new_proxyids={
        "sysadmin001.weibo.imgbed.qxg.sinanode.com":"10395",
        "sysadmin001.weibo.imgbed.bx.sinanode.com":"10396",
        "zbx001.weibo.imgbed.hy.sinanode.com":"10397"}
group_list={}
    
with open("./host_group") as f:
    while 1:
        line=f.readline()
        if not line.strip():
            break
        else:
            groupid=get_group(line.strip())
            group_list[line.strip()]=groupid
for k,v in proxyids.items():
    rt=get_host(v)
    for host in json.loads(rt)["result"]:
        host_create(host,new_proxyids[k]) 
