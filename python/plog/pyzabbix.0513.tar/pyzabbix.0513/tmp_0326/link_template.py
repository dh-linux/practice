from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def get_host_info(host):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    if host!="all":
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "filter": {
                        "host":["%s" % host]
                    }
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text
def add_template(rt_text,templateid_list,group_dict):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    for host_info in json.loads(rt_text)["result"]:

        
        templateid_list_tmp=templateid_list[:]
        hostid=host_info["hostid"]
        
        for  group in  host_info["groups"]:
            group_name=group["name"]
            if group_name in group_dict.keys():
                templateid_list_tmp.append({"templateid":group_dict[group_name]})
        print host_info["name"]
        rt=zb.host.update(
                {
                    "hostid":hostid,
                    "templates":templateid_list_tmp
                    
                })
        print json.dumps(json.loads(rt.text),indent=2)
group_list={
    "sina weiboimg upload":"Template Log Upload - httplog status"
}
templates_list=[
    "Template App Zabbix Agent",
    "Template OS Filesystem Status",
    "Template OS HardWare raid",
    "Template OS Linux",
    "Template OS Network Status"
]
group_dict={}
for k,v in group_list.items():
    templateid=get_template_id(v)
    group_dict[k]=templateid

rt_text_tmp=get_host_info("all")
templateid_list=[]
for template in templates_list:
    templateid=get_template_id(template)
    templateid_list.append({"templateid":templateid})

add_template(rt_text_tmp,templateid_list,group_dict)
