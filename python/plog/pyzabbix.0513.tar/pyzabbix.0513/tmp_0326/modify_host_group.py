from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_hostid(host_name):

    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.host.get(
        {
            "output": "extend",
            "selectGroups": "extend",
            "filter": {
                "host": [
                    "%s" % host_name,
                ]
            }
        })
    if len(json.loads(response.text)["result"])==0:
        return -1
    else:
        return  json.loads(response.text)["result"][0]["hostid"]

def update_host(host_id,groupids):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    
    group_list=[]
    for id in groupids.split(","):
        group_list.append({"groupid":"%s" % id})

    response=zb.host.update(
            {
                "hostid": "%s" % host_id,
                "groups": group_list,
            })
    print json.dumps(json.loads(response.text),indent=2)




def add_host(host_name,host_ip):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb..create(
            {
                "description":description,
                "expression":"%s" % expression,
                "priority":priority
            })
    print json.dumps(json.loads(response.text),indent=2)

def get_groupid(group_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.hostgroup.get(
            {
            
                "output": "extend",
                "filter": {
                    "name": [
                        "%s" % group_name
                    ]
                }
            })
    return  json.loads(response.text)["result"][0]["groupid"]
    print json.dumps(json.loads(response.text),indent=2)
    
proxy_dict={
    "bx" :"sysadmin001.weibo.imgbed.bx.sinanode.com",
    "gz" :"sysadmin001.weibo.imgbed.qxg.sinanode.com",
    "sx" :"sysadmin001.weibo.imgbed.qxg.sinanode.com",
    "yf" :"sysadmin001.weibo.imgbed.bx.sinanode.com",
    "yz" :"sysadmin001.weibo.imgbed.bx.sinanode.com"
}
group_dict={
    "bx" :"sina weiboimg notefs,All Discovered hosts,sina weiboimg notefs beijing",
    "gz" :"sina weiboimg notefs,All Discovered hosts,sina weiboimg notefs guangzhou",
    "sx" :"sina weiboimg notefs,All Discovered hosts,sina weiboimg notefs guangzhou",
    "yf" :"sina weiboimg notefs,All Discovered hosts,sina weiboimg notefs beijing",
    "yz" :"sina weiboimg notefs,All Discovered hosts,sina weiboimg notefs beijing"
}

with open("./host_list") as file_handle:
    while 1:
        line = file_handle.readline()
        if not line:
            break
        else:
            host_name=line.split()[0].strip()
            location=host_name.split('.')[3]
            hostid=get_hostid(host_name)
            groupids=""
            if int(hostid)!=-1:
                for group_name in group_dict[location].split(","):
                    groupids+=get_groupid(group_name.strip())+","
                update_host(hostid,groupids[0:-1])
                print host_name
