from pyzabbix import zabbixapi
import json


url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def add_group_host():
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.hostgroup.get(
            {
                "output":"extend",
            })
    for  host_group in  json.loads(response.text)["result"]:
        name=host_group["name"]
        if name.find("_")!=-1 or name.find("-")!=-1:
            continue
        else:
            rt=zb.host.create(
                    {
                        "host": "%s" % name ,
                        "interfaces": [
                            {
                                "type": 1,
                                "main": 1,
                                "useip": 1,
                                "ip": "127.0.0.1",
                                "dns": "",
                                "port": "10050"
                            }
                        ],
                        "groups": [
                            {
                                "groupid": "113"
                            }
                        ]
                    })
            print json.dumps(json.loads(rt.text),indent=2)
add_group_host()
