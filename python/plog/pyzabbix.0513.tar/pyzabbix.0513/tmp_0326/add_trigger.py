from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def add_trigger(description,expression,priority):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.trigger.create(
            {
                "description":description,
                "expression":"%s" % expression,
                "priority":priority
            })
    print json.dumps(json.loads(response.text),indent=2)
pic_type='bmiddle cmw218 large mw1024 mw600 mw690 nmw690 others small square thumb150 thumb180 thumb300 thumb50 thumbnail wap120 wap128 wap180 wap240 wap360 wap690 wap720 webp180 webp360 webp720 woriginal'
for pic in pic_type.split():
    description='Total(cacheL2) - /%s/ rt&4xx&5xx' % pic
    expression='{Template Log CacheL2 - ATS get log Summary:grpavg["{HOST.HOST}","cacheL2get_%s_avgrt",last,0].min(#3)}>300|{Template Log CacheL2 - ATS get log Summary:grpsum["{HOST.HOST}","cacheL2get_%s_4xx",last,0].min(#3)}>300|{Template Log CacheL2 - ATS get log Summary:grpsum["{HOST.HOST}","cacheL2get_%s_5xx",last,0].last()}>5' % (pic,pic,pic)

    print description,expression
    add_trigger(description,expression,4)
