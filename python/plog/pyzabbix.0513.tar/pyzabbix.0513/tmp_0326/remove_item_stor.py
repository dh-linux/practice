from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def get_host_info(host):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    if host!="all":
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "filter": {
                        "host":["%s" % host]
                    }
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text
def add_template(rt_text,templateid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    for host_info in json.loads(rt_text)["result"]:
        templateid_list=[]
        if "parentTemplates" in host_info:
            for templates in host_info["parentTemplates"]:
                del templates["name"]
                templateid_list.append(templates)
        if {'templateid':templateid} not in  templateid_list:
            templateid_list.append({'templateid':templateid})
            hostid=host_info["hostid"]
            rt=zb.host.update(
                    {
                        "hostid":hostid,
                        "templates":templateid_list
                        
                    })
            
            print host_info["name"]
            print json.dumps(json.loads(rt.text),indent=2)

def remove_item(hostid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    rt=zb.item.get(
            {
                "output": "extend",
                "hostids": "%s" % hostid,
            })
    for item in json.loads(rt.text)["result"]:
        rt=zb.item.delete(
            ["%s"%item["itemid"]]
        )
        print json.dumps(json.loads(rt.text),indent=2)


rt_text_tmp=get_host_info("all")
for host in  json.loads(rt_text_tmp)["result"]:
    if host["name"].find("sinanode.com")!=-1 and host["name"].startswith("st"):
        remove_item( host["hostid"])
