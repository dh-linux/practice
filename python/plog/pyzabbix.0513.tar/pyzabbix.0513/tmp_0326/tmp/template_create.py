from pyzabbix import zabbixapi
import json

def get_template_id(template_name):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.template.create(
            {
                "host": "%s" % template_name,
                "groups": {
                    "groupid": 132
                },
            })
    
    print json.dumps(json.loads(response.text),indent=2)

get_template_id("just a text")
