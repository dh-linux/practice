from pyzabbix import zabbixapi
import json
#url="http://10.210.71.145/zabbix/api_jsonrpc.php"
#zb=zabbixapi(url=url,user="admin",password="zabbix")
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
zb=zabbixapi(url=url,user="baoning1",password="1234qwe")
host_group=["gz-summary","tj-summary","bj-summary","all-summary"]
#host_group=["all-summary"]
template_group={
        "apache":["Apache-stats"]
    }
role_dict={
    "gz-summary":{
        "apache":["Weibo_img-Upload-TJCNC"],
    },

    "bj-summary":{
        "apache":["Weibo_img-Upload-BJCNC","Weibo_img-Upload-BJCT"],
    },
    "tj-summary":{
        "apache":["Weibo_img-Upload-TJCNC"],
    },
    "all-summary":{
        "apache":["Weibo_img-Upload"],
    }
}
for template_key,template_value in  template_group.items():
    for template_item in template_value:
        for   _host  in  host_group:
            response=zb.host.get(
                    {
                        "output":["interfaceid","hostids"],
                        "filter": 
                        {
                            "host":_host
                        },
                        "selectInterfaces":["interfaceid"]
                    })
            interfaceid=json.loads(response.text)["result"][0]["interfaces"][0]["interfaceid"]
            host_id=json.loads(response.text)["result"][0]["hostid"]

            response=zb.template.get(
                    {
                        "output":"extend",
                        "filter": 
                        {
                            "host": ["%s" % template_item]
                        }
                    })
            templateid=json.loads(response.text)["result"][0]["templateid"]
            params={
                    "output":"extend",
                    "hostids":templateid
                }
            response=zb.item.get(params)
            item_list=json.loads(response.text)["result"]


            for item in item_list:
                name_prefix=item["name"]
                name="Total(%s)-%s" % (template_key,name_prefix)
                host_group_name=role_dict[_host][template_key]

                if  len(host_group_name)==1:
                    key='grpsum["%s","%s",last,0]' %(host_group_name[0].strip(),item["key_"].strip())
                if len(host_group_name)==2:
                    key='grpsum[["%s","%s"],"%s",last,0]' %(host_group_name[0].strip(),host_group_name[1].strip(),item["key_"].strip())
                print  key
                params={
                    "name": name,
                    "key_": key,
                    "hostid": host_id,
                    "type": 8,
                    "value_type": 3,
                    "interfaceid": interfaceid,
                    "delay": 60,
                    "application":92475
                }
                response=zb.item.create(params)
                print json.dumps(json.loads(response.text),indent=2)
