from pyzabbix import zabbixapi
import json


def get_templateid(template_name):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    return json.loads(response.text)["result"][0]["templateid"]
    

def get_item(hostids):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.item.get(
            {
                "output":"extend",
                "hostids":hostids
            })
    return response

def create_template(template_name):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.template.create(
            {
                "host": "%s" % template_name,
                "groups": {
                    "groupid": 132
                },
            })
    print json.dumps(json.loads(response.text),indent=2)
    

def add_item(templateid,template_name):
    summary_name=template_name+" Summary"
    template_dict={ 
                "Template Log CacheL2 - ATS get log":"CacheL2",
                    "Template  Log  Center - center log":"Center",
                    "Template Log Service - http access":"Service",
                    "Template Log Storage - http access":"Storage",
                    "Template Log Upload - httplog status":"Upload",
                    "Template Log Webpress - imgshow lua":"Webpress",
                    "Template Log  Webpress - nginx access":"Webpress",
                    "Template Log Webpress - Presser access":"Webpress",
                    "Template OS Network Status":"Network"
    }

    service=template_dict[template_name]


    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    create_template(summary_name)
    summary_templateid=get_templateid(summary_name)

    response=get_item(templateid)

    for item in json.loads(response.text)["result"]:
        name=item["name"]
        key=item["key_"]
        if key.find("avg")!=-1:
            key='grpavg["{HOST.HOST}","'+key+'",last,0]'
            name="Avg(%s)-%s" % (service,name)
        else:
            key='grpsum["{HOST.HOST}","'+key+'",last,0]'
            name="Sum(%s)-%s" % (service,name)
        print key , name 
        params={
            "name": name,
            "key_": key,
            "hostid": summary_templateid,
            "type": 2,
            "value_type": 3,
            "interfaceid": "",
            "delay": 60
        }
        response=zb.item.create(params)
        print json.dumps(json.loads(response.text),indent=2)


    
template_name=[ "Template Log CacheL2 - ATS get log",
                "Template  Log  Center - center log",
                "Template Log Service - http access",
                "Template Log Storage - http access",
                "Template Log Upload - httplog status",
                "Template Log Webpress - imgshow lua",
                "Template Log  Webpress - nginx access",
                "Template Log Webpress - Presser access",
                "Template OS Network Status"
            ]

for template in template_name:
    templateid=get_templateid(template)
    add_item(templateid,template)
