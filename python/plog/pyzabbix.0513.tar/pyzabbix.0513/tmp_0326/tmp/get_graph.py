from pyzabbix import zabbixapi
import json
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
zb=zabbixapi(url=url,user="baoning1",password="123qwe")
host_group=["all-summary","bj-summary","tj-summary","gz-summary"]
template_group=["Template_webpress_ngxacc_status","Template_uploadhttplog_status",
                "Template_presser_access_status","Template_imgshow_lua_status",
                "Template_cachel2_getlog_status"]
for host_city in host_group:
    response=zb.host.get(
            {
                "output":"extend",
                "filter": 
                {
                    "host":"%s" % host_city
                }
            })
    response=zb.host.get({"output":"hostid","filter": {"host": ["%s" % host_city]}})
    hostid=json.loads(response.text)["result"][0]["hostid"]
    response=zb.item.get(
            {
                "output": "extend",
                "hostids":hostid,
                "sortfield": "name",
            })
    item_dict={}
    for item in json.loads(response.text)["result"]:
        key=item["key_"].split('"')[-2]
        itemid=item["itemid"]
        item_dict[key]=itemid

    for template_name in template_group:
        response=zb.host.get(
                {
                    "output":["hostid","templated_hosts"],
                    "templated_hosts":1,
                    "filter": 
                    {
                        "host":"%s" % template_name
                    }
                })

        hostid=json.loads(response.text)["result"][0]["hostid"]
        response=zb.graph.get(
                {
                    "output": "extend",
                    "hostids": hostid
                })
        for  template_item in json.loads(response.text)["result"]:
            name="Total("+template_item["name"].split()[0]+") - "+" ".join(template_item["name"].split()[2:])
            graph_id=template_item["graphid"]
            response=zb.graphitem.get(
                {
                    "output": "extend",
                    "expandData": 1,
                    "graphids":graph_id
                })
            print json.dumps(json.loads(response.text),indent=2)
            
            gitems=[]
            for  item in json.loads(response.text)["result"]:
                
                key=item["key_"]
                gitems.append({"itemid":item_dict[key],"drawtype":item["drawtype"],"yaxisside":item["yaxisside"],"color":item["color"],"sortorder":item["sortorder"]})
            response=zb.graph.create(
                    {
                        "name": name, 
                        "width": 900,
                        "height": 200,
                        "gitems":gitems
                    })
            print json.dumps(json.loads(response.text),indent=2)
            del gitems[:]"""
