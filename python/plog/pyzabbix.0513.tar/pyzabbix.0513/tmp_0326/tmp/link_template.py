from pyzabbix import zabbixapi
import json

def get_template_id(template_name):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def get_host_info_old(host):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    if host!="all":
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "filter": {
                        "host":["%s" % host]
                    }
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text
def add_template(rt_text,templateid):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    for host_info in json.loads(rt_text)["result"]:
        templateid_list=[]
        if "parentTemplates" in host_info:
            for templates in host_info["parentTemplates"]:
                del templates["name"]
                templateid_list.append(templates)
        if {'templateid':templateid} not in  templateid_list:
            templateid_list.append({'templateid':templateid})
            hostid=host_info["hostid"]
            print templateid_list
            rt=zb.host.update(
                    {
                        "hostid":hostid,
                        "templates":templateid_list
                        
                    })
            
            print json.dumps(json.loads(rt.text),indent=2)
templateid=get_template_id("")
rt_text_tmp=get_host_info_old("all")
for  host in json.loads(rt_text_tmp)["result"]:
    if host["name"].find("svc") == 0:
        host_name=host["name"]
        rt_text=get_host_info_old(host_name)
        add_template(rt_text,templateid)
