from pyzabbix import zabbixapi
import json


def get_host_id(template_name):
    url="http://10.210.71.145/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="admin",password="zabbix")
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]
def add_item(hostid,service,service_prefix,item_file):
    url="http://10.210.71.145/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="admin",password="zabbix")
    with open(item_file) as file_handle:
        while 1:
            line = file_handle.readline()
            if not line:
                break
            else:
                if line.find("xx")!=-1 and line.find("_")==-1:
                    name="%s response code==%s" %(service,line.strip())
                    key="%s_%s" %(service_prefix,line.strip())
                if line.find("xx")!=-1 and line.find("_")!=-1:
                    name="%s  pictype==%s and response code == %s" %(service,line.strip().split("_")[0],line.strip().split("_")[1])
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("ms")!=-1 and line.find("_")==-1:
                    name="%s response time==(%s)" %(service,line.strip())
                    key="%s_%s" %(service_prefix,line.strip())
                if line.find("ms")!=-1 and line.find("_")!=-1:
                    name="%s  pictype==%s and response time == (%s)" %(service,line.strip().split("_")[0],line.strip().split("_")[1])
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("avgrt")!=-1 and line.find("_")==-1:
                    name="%s avg response time" %(service)
                    key="%s_%s" %(service_prefix,line.strip())
                if line.find("avgrt")!=-1 and line.find("_")!=-1:
                    name="%s  pictype==%s and  avg response time" %(service,line.strip().split("_")[0])
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("count")!=-1 and line.find("_")==-1:
                    name="%s count" %(service)
                    key="%s_%s" %(service_prefix,line.strip())
                if line.find("count")!=-1 and line.find("_")!=-1:
                    name="%s  pictype==%s and  count" %(service,line.strip().split("_")[0])
                    key="%s_%s" %(service_prefix,line.strip())
                params={
                    "name": name,
                    "key_": key,
                    "hostid": hostid,
                    "type": 2,
                    "value_type": 3,
                    "interfaceid": "",
                    "delay": 60
                }
                response=zb.item.create(params)
                print json.dumps(json.loads(response.text),indent=2)
hostid=get_host_id("Template Log Service   access")
add_item(hostid,"service","servicehttpd","./item_file")
