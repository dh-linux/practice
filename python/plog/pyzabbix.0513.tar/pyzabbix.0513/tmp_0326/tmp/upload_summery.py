from pyzabbix import zabbixapi
import json
#url="http://10.210.71.145/zabbix/api_jsonrpc.php"
#zb=zabbixapi(url=url,user="admin",password="zabbix")
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
zb=zabbixapi(url=url,user="baoning1",password="123qwe")
host_group=["gz-summary","tj-summary","bj-summary","all-summary"]
host_dict={
    "gz-summary":"Weibo_img-Upload-GZCT",
    "tj-summary":"Weibo_img-Upload-TJCNC",
    "all-summary":"Weibo_img-Upload",
    "bj-summary":"Weibo_img-Upload-BJCNC,Weibo_img-Upload-BJCT"
}
for   _host  in  host_group:

    response=zb.host.get(
            {
                "output":["interfaceid","hostids"],
                "filter": 
                {
                    "host":_host
                },
                "selectInterfaces":["interfaceid"]
            })
    interfaceid=json.loads(response.text)["result"][0]["interfaces"][0]["interfaceid"]
    host_id=json.loads(response.text)["result"][0]["hostid"]

    response=zb.template.get(
            {
                "output":"extend",
                "filter": 
                {
                    "host": ["Template_uploadhttplog_status"]
                }
            })
    templateid=json.loads(response.text)["result"][0]["templateid"]
    params={
            "output":"extend",
            "hostids":templateid
        }
    response=zb.item.get(params)
    item_list=json.loads(response.text)["result"]

    host_group_name=host_dict[_host].split(",")

    for item in item_list:
        name_prefix=item["name"]
        name="Total(upload)-"+name_prefix
        if  len(host_group_name)==1:
            key='grpsum["%s","%s",last,0]' %(host_group_name[0].strip(),item["key_"].strip())
        if len(host_group_name)==2:
            key='grpsum[["%s","%s"],"%s",last,0]' %(host_group_name[0].strip(),host_group_name[1].strip(),item["key_"].strip())
        params={
            "name": name,
            "key_": key,
            "hostid": host_id,
            "type": 8,
            "value_type": 3,
            "interfaceid": interfaceid,
            "delay": 60,
            "application":92475
        }
        response=zb.item.create(params)
        print json.dumps(json.loads(response.text),indent=2)
