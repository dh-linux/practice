from pyzabbix import zabbixapi
import json
#url="http://10.210.71.145/zabbix/api_jsonrpc.php"
#zb=zabbixapi(url=url,user="admin",password="zabbix")
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
zb=zabbixapi(url=url,user="baoning1",password="123qwe")
response=zb.host.get(
        {
            "output":["hostid","templated_hosts"],
            "templated_hosts":1,
            "filter": 
            {
                "name":"Template_uploadhttplog_status"
            }
        })
print "with (templated_hosts:1)"
print json.dumps(json.loads(response.text),indent=2)
hostid=json.loads(response.text)["result"][0]["hostid"]
urls=["pic_upload.php","crossdomain.xml","interface_pic_upload.php","interface_upload.php"]
response_time=["500ms","500-1000ms","1000-2000ms","2000-4000ms","4000ms","avgtime"]

name="uploadhttpd url==%s and responsetime(%s)"
key="uploadhttpd_"
for url in urls:
    for rt in response_time:
        print name %(url,rt),key+url+"_"+rt
        params={
            "name": name %(url,rt),
            "key_": key+url+"_"+rt,
            "hostid": hostid,
            "type": 2,
            "value_type": 3,
            "interfaceid": "",
            "delay": 60
        }
        response=zb.item.create(params)
        print json.dumps(json.loads(response.text),indent=2)
