from pyzabbix import zabbixapi
import json
#url="http://10.210.71.145/zabbix/api_jsonrpc.php"
#zb=zabbixapi(url=url,user="admin",password="zabbix")

def get_item_id(hostids):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.item.get(
            {
                "output":"extend",
                "hostids":hostids
            })
    
    for item in  json.loads(response.text)["result"]:
        if item["key_"].find("grp")==-1:
            rt=zb.item.delete(
                {
                    "params":[
                        item["itemid"]
                    ],
                })
def get_host_id(host_city):
    hostids=[]
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    if host_city=="all":
        response=zb.host.get(
                {
                    "output": "extend",
                })

    else:
        response=zb.host.get(
                {
                    "output": "extend",
                    "filter": 
                    {
                        "host":"%s" % host_city
                    }

                })
    for id in json.loads(response.text)["result"]:
        hostids.append(id["hostid"])
    return hostids

def delete_graph():
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    rt=zb.graph.delete(
            {
                "params": 
                ["67493"],
            })
    print json.dumps(json.loads(rt.text),indent=2)

def get_host_info(host):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    if host!="all":
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "filter": {
                        "host":["%s" % host]
                    }
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text
def get_host_info_old(host):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    if host!="all":
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "filter": {
                        "host":["%s" % host]
                    }
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text

def delete_host(hostid):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    print { "params": ["%s" % hostid]}
    print "#"*10
    response=zb.host.delete(
            {
                "params":["16262"],
            })
    print json.dumps(json.loads(response.text),indent=2)
    print "#"*10

def add_host(rt_text):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    for host_info in json.loads(rt_text)["result"]:
        
        if host_info["host"].find("sinanode.com")!=-1:
            continue

        host = ".".join(host_info["host"].split(".")[0:-2])

        print host_info["host"]

        del host_info["interfaces"][0]["interfaceid"]
        del host_info["interfaces"][0]["hostid"]

        interfaces=host_info["interfaces"]
        for g in host_info["groups"]:
            del g["internal"]
            del g["flags"]
            del g["name"]
        groups=host_info["groups"]
        print host_info
        rt=zb.host.create(
                {
                    "host": host,
                    "interfaces":interfaces ,
                    "proxy_hostid":host_info["proxy_hostid"],
                    "groups":groups,
                })
        print json.dumps(json.loads(rt.text),indent=2)

def update_host(rt_text):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    for host_info in json.loads(rt_text)["result"]:
        hostid=host_info["hostid"]
        host = host_info["host"]
        if host.find("sinanode.com") == -1:
            host=host+".sinanode.com"
            print host
        rt=zb.host.update(
                {
                    #"name": host,
                    "host":host,
                    "hostid":hostid
                })
        print json.dumps(json.loads(rt.text),indent=2)
def add_template(rt_text,templateid):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    
    print json.dumps(json.loads(rt_text),indent=2)
    '''
    for host_info in json.loads(rt_text)["result"]:
        print host_info
        templateid_list=[]
        if "parentTemplates" in host_info:
            print host_info["parentTemplates"]
            for templates in host_info["parentTemplates"]:
                del templates["name"]
                templateid_list.append(templates)
        templateid_list.append({'templateid':templateid})
        hostid=host_info["hostid"]
        #print templateid_list
        #rt=zb.host.update(
        #        {
        #            "hostid":hostid,
        #            "templates":templateid_list
        #            
        #        })
        
        #print json.dumps(json.loads(rt.text),indent=2)
    '''
def get_template_id(template_name):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def add_lost_host(rt_text):
    url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    for host_info in json.loads(rt_text)["result"]:
        if host_info["host"].find("imgbed")!=-1:
            host = host_info["host"]

            del host_info["interfaces"][0]["interfaceid"]
            del host_info["interfaces"][0]["hostid"]

            interfaces=host_info["interfaces"]
            for g in host_info["groups"]:
                del g["internal"]
                del g["flags"]
                del g["name"]
            groups=host_info["groups"]
            print host
            rt=zb.host.create(
                    {
                        "host": host,
                        "interfaces":interfaces ,
                        "proxy_hostid":host_info["proxy_hostid"],
                        "groups":groups,
                    })
            print json.dumps(json.loads(rt.text),indent=2)
            break
def  repair_lost_host():
    with open("/tmp/lost_host") as read_handle:
        while 1:
            line=read_handle.readline()
            if not line:
                break
            else:
                rt_text=get_host_info(line.strip())
                templateid=get_template_id("Template OS Basic")
                add_template(rt_text,templateid)

def get_template_item(template_name):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")


    response=zb.host.get(
            {
                "output":"extend",
                "templated_hosts":1,
                "interfaceid":1,
                "filter": 
                {
                    "name":"%s" % template_name
                }
            })
    print json.dumps(json.loads(response.text),indent=2)
    hostid=json.loads(response.text)["result"][0]["hostid"]

    response=zb.item.get(
            {
                "output":"extend",
                "hostids":hostid
            })
    
    params={
        "name": "",
        "key_": "",
        "hostid": hostid,
        "type": "",
        "value_type": "",
        "interfaceid": "",
        "delay": 60
    }
    add_list=["unistore.weibo.cn","i.unistore.weibo.cn"]
    for  key in  add_list:
        for item in  json.loads(response.text)["result"]:
            if item["key_"].find("upload.t.sinaimg.cn")!=-1:
                params["key_"]=item["key_"].replace("upload.t.sinaimg.cn",key)
                params["name"]=item["name"].replace("upload.t.sinaimg.cn",key)
                params["type"]=item["type"]
                params["value_type"]=item["value_type"]
                params["interfaceid"]=item["interfaceid"]
                #print json.dumps(params,indent=2)
                rt_text=zb.item.create(
                    params
                )
                print json.dumps(json.loads(rt_text.text),indent=2)
def get_graph_id(hostids,graph_name):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.graph.get(
            {
                "output":"extend",
                "hostids":hostids
            })
    for  graph in json.loads(response.text)["result"]:
        if graph["name"] == graph_name:
            return graph["graphid"]

def add_graph(hostid,graph_id):
    print hostid,graph_id
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.graph.get(
            {
                "output":"extend",
                "graphids":graph_id,
                "selectItems":1,
                "selectHosts":1,
                "selectGraphItems":1,
            })
    print json.dumps(json.loads(response.text),indent=2)

def add_template(rt_text,templateid):
    url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    for host_info in json.loads(rt_text)["result"]:
        if host_info["host"].find("stor")!=-1:
            print host_info["host"]
            templateid_list=[]
            if "parentTemplates" in host_info:
                print host_info["parentTemplates"]
                for templates in host_info["parentTemplates"]:
                    del templates["name"]
                    templateid_list.append(templates)
            templateid_list.append({'templateid':templateid})
            hostid=host_info["hostid"]
            rt=zb.host.update(
                    {
                        "hostid":hostid,
                        "templates":templateid_list
                        
                    })
            print json.dumps(json.loads(rt.text),indent=2)

def update_graph(template_name):
    url="http://10.77.96.26/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.host.get(
            {
                "output":"extend",
                "templated_hosts":1,
                "interfaceid":1,
                "filter": 
                {
                    "name":"%s" % template_name
                }
            })
    print json.dumps(json.loads(response.text),indent=2)
    hostid=json.loads(response.text)["result"][0]["hostid"]

    response=zb.graph.get(
            {
                "output":"extend",
                "hostids":hostid
            })
    
    for graph in json.loads(response.text)["result"]:
        graphid=graph["graphid"]
        name = graph["name"]
        temp_name=name.split("---")[0]+"-"+name.split("---")[-1]
        response=zb.graph.update(
            {
                "graphid":"%s" % graphid,
                "name":"%s" % temp_name
            })
        print json.dumps(json.loads(response.text),indent=2)
def get_host_group():
    url="http://10.77.96.26/zabbix/api_jsonrpc.php"
    zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
    response=zb.hostgroup.get(
            {
                "output":"extend",
            })
    for  host_group in  json.loads(response.text)["result"]:
        name=host_group["name"]
        if name.find("_")!=-1 or name.find("-")!=-1:
            continue
        else:
            rt=zb.host.create(
                    {
                        "host": "%s" % name ,
                        "interfaces": [
                            {
                                "type": 1,
                                "main": 1,
                                "useip": 1,
                                "ip": "127.0.0.1",
                                "dns": "",
                                "port": "10050"
                            }
                        ],
                        "groups": [
                            {
                                "groupid": "113"
                            }
                        ]
                    })
            print json.dumps(json.loads(rt.text),indent=2)

#get_host_group()
#update_graph("Template APP cacheL2 ATS get log")

templateid=get_template_id("Template Log storage access")
rt_text_tmp=get_host_info_old("all")
for  host in json.loads(rt_text_tmp)["result"]:
    if host["name"].find("stor") == 0:
        host_name=host["name"]
        rt_text=get_host_info_old(host_name)
        add_template(rt_text,templateid)


#templateid=get_template_id("Template App storage monitor")

#add_template(rt_text,templateid)

#print json.dumps(json.loads(rt_text),indent=2)


'''
host_list=["all-summary","bj-summary","gz-summary","tj-summary"]
for host  in host_list:
    get_template_item(host)
hostid=gdd_templateet_host_id("all-summary")
graph_id=get_graph_id(hostid,"Total(upload) - error 4xx")
hostid=get_host_id("bj-summary")

add_graph(hostid,graph_id)

'''

#repair_lost_host()
#rt_text=get_host_info("all")
#for host in  json.loads(rt_text)["result"]:
#    if len(host["parentTemplates"])!=1:
#        print host["host"]
#    break
