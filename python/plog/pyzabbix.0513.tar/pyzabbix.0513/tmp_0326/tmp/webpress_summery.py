from pyzabbix import zabbixapi
import json
#url="http://10.210.71.145/zabbix/api_jsonrpc.php"
#zb=zabbixapi(url=url,user="admin",password="zabbix")
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
zb=zabbixapi(url=url,user="baoning1",password="123qwe")
response=zb.item.get(
        {
            "output":"extend",
            "filter": 
            {
                "host":"all-summary"
            }
        })
item_list=json.loads(response.text)["result"]
prefix=["500ms","500-1000ms","1000-2000ms","2000-4000ms","4000ms","avg"]
color=["00C800","0000C8","C800C8","00C8C8","C80000","C8C800"]
item_dict={}
for item in item_list:
    key=item["key_"].split(',')[1].strip('"')
    id=item["itemid"]
    if key.startswith("webpress"):
        try:
            item_time=key.split("_")[3]
        except:
            continue
        item_key=key.split("_")[2]
        if item_time not in prefix:
            continue
        if item_key not in item_dict:
            item_dict[item_key]={}
        if item_time.startswith("500ms"):
            item_dict[item_key][0]=id 
        elif item_time.startswith("500-"):
            item_dict[item_key][1]=id 
        elif item_time.startswith("1000-"):
            item_dict[item_key][2]=id 
        elif item_time.startswith("2000-"):
            item_dict[item_key][3]=id 
        elif item_time.startswith("4000ms"):
            item_dict[item_key][4]=id 
        elif item_time.startswith("avg"):
            item_dict[item_key][5]=id 
gitems=[]
for key,value in item_dict.items():
    name="Total(webpress) - /%s/ response time" % key
    for k,v in item_dict[key].items():
        if k!=5:
            gitems.append({"itemid":v,"color":color[k],"sortorder":k,"drawtype":1})
        else:
            gitems.append({"itemid":v,"color":color[k],"sortorder":k,"yaxisside":1})
    response=zb.graph.create(
        {   
            "name": name, 
            "width": 900,
            "height": 200,
            "gitems":gitems
        })
    
    print json.dumps(json.loads(response.text),indent=2)
    del gitems[:]  

