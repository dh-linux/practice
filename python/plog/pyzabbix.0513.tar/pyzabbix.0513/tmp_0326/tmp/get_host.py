from pyzabbix import zabbixapi
import json
url="http://10.77.96.26/zabbix/api_jsonrpc.php"
#log in 
zb=zabbixapi(url=url,user="baoning1",password="1234qwer")
response=zb.host.get(
        {
            "output":"extend",
        })
print json.dumps(json.loads(response.text),indent=2)
