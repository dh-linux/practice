from pyzabbix import zabbixapi
import json


url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
def update_graph(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)

    response=zb.host.get(
            {
                "output":"extend",
                "templated_hosts":1,
                "interfaceid":1,
                "filter": 
                {
                    "name":"%s" % template_name
                }
            })
    hostid=json.loads(response.text)["result"][0]["hostid"]

    response=zb.graph.get(
            {
                "output":"extend",
                "hostids":hostid
            })
    
    for graph in json.loads(response.text)["result"]:
        graphid=graph["graphid"]
        name = graph["name"]
        if name.endswith(" count"):
            temp_name=" ".join(name.split()[0:-1])
            print temp_name
            response=zb.graph.update(
                {
                    "graphid":"%s" % graphid,
                    "name":"%s" % temp_name
                })
            print json.dumps(json.loads(response.text),indent=2)
template_name=[
    "Template Log Service - http access",
    "Template Log CacheL2 - ATS get log",
    "Template Log Webpress - nginx access",
    "Template Log Upload - httplog status"
]
for  i in template_name:
    update_graph(i)
    update_graph(i+" Summary")
