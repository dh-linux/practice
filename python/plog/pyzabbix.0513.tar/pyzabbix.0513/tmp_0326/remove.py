from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"
def get_template_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    return json.loads(response.text)["result"][0]["templateid"]

def get_host_info(host):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    if host!="all":
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                    "filter": {
                        "host":["%s" % host]
                    }
                })
    else:
        rt=zb.host.get(
                {
                    "output": "extend",
                    "selectGroups": "extend",
                    "selectInterfaces":"extend",
                    "selectParentTemplates": [
                        "templateid",
                        "name"
                    ],
                })
    return rt.text
def get_group_id(group_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    rt=zb.hostgroup.get(
            {
                "output": "extend",
                "filter": {
                    "name":["%s" % group_name]
                }
            })
    print json.dumps(json.loads(rt.text),indent=2)
    return json.loads(rt.text)["result"][0]["groupid"]

def get_host_info_group(group_id):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    rt=zb.host.get(
            {
                "output": "extend",
                "selectGroups": "extend",
                "selectInterfaces":"extend",
                "selectParentTemplates": [
                    "templateid",
                    "name"
                ],
                "filter": {
                    "groupids":["%s" % group_id]
                }
            })
    return rt.text
def add_template(rt_text,templateid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    for host_info in json.loads(rt_text)["result"]:
        templateid_list=[]
        if "parentTemplates" in host_info:
            for templates in host_info["parentTemplates"]:
                del templates["name"]
                templateid_list.append(templates)
        if {'templateid':templateid} not in  templateid_list:
            templateid_list.append({'templateid':templateid})
            hostid=host_info["hostid"]
            rt=zb.host.update(
                    {
                        "hostid":hostid,
                        "templates":templateid_list
                        
                    })
            
            print json.dumps(json.loads(rt.text),indent=2)

def remove_template(rt_text,templateid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    for host_info in json.loads(rt_text)["result"]:
        templateid_list=[]
        if "parentTemplates" in host_info:
            for templates in host_info["parentTemplates"]:
                del templates["name"]
                templateid_list.append(templates)
        if {'templateid':templateid} not in  templateid_list:
            pass 
        else:

            print "#"*10
            hostid=host_info["hostid"]
            rt=zb.host.update(
                    {
                        "hostid":hostid,
                        "templates_clear":[
                            {'templateid':templateid}
                        ]
                    })
            print json.dumps(json.loads(rt.text),indent=2)
            print "#"*10

def remove_template(rt_text,templateid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    for host_info in json.loads(rt_text)["result"]:
        templateid_list=[]
        if "parentTemplates" in host_info:
            for templates in host_info["parentTemplates"]:
                del templates["name"]
                templateid_list.append(templates)
        if {'templateid':templateid} not in  templateid_list:
            pass 
        else:

            print "#"*10
            hostid=host_info["hostid"]
            name=host_info["name"]
            print name
            rt=zb.host.update(
                    {
                        "hostid":hostid,
                        "templates_clear":[
                            {'templateid':templateid}
                        ]
                    })
            print json.dumps(json.loads(rt.text),indent=2)
            print "#"*10

group_list=["All IDC Img Server"]
templates_list=[
    "Template App Zabbix Agent",
    "Template OS Filesystem Status",
    "Template OS HardWare raid",
    "Template OS Linux",
    "Template OS Network Status"
]
for template in templates_list:
    templateid=get_template_id(template)
    for group_name in group_list:
        group_id=get_group_id(group_name)
        rt_text_tmp=get_host_info_group(group_id)
        print json.dumps(json.loads(rt_text_tmp),indent=2)
        #remove_template(rt_text_tmp,templateid)
