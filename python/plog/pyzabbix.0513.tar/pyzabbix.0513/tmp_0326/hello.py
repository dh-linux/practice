with open("./time_type") as a:
    while 1:
        line=a.readline()
        if not line:
            break
        else:
            print line.strip()
with open("./response_code") as a:
    while 1:
        line=a.readline()
        if not line:
            break
        else:
            print line.strip()

#print "total_time"
with open("./pic_type") as a:
    while 1:
        pic_type=a.readline()
        if not pic_type:
            break
        else:
            with open("./time_type") as a1:
                while 1:
                    time_type=a1.readline()
                    if not time_type:
                        break
                    else:
                        print pic_type.strip()+"_"+time_type.strip()
            with open("./response_code") as a2:
                while 1:
                    response_code=a2.readline()
                    if not response_code:
                        break
                    else:
                        print pic_type.strip()+"_"+response_code.strip()
            #print pic_type.strip()+"_total_time"
