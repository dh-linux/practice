from pyzabbix import zabbixapi
import json


url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx002.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_host_id(template_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.template.get(
            {
                "output":"extend",
                "filter":{
                    "host":[
                        "%s" % template_name
                    ]
                }
            })
    
    print json.dumps(json.loads(response.text),indent=2)
    return json.loads(response.text)["result"][0]["templateid"]

def add_item(hostid,service,service_prefix,item_file):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    with open(item_file) as file_handle:
        while 1:
            line = file_handle.readline()
            if not line:
                break
            else:

                ##### some logic judgment    

                if line.find("xx")!=-1 and line.find("_")==-1:
                    name="%s response code==%s" %(service,line.strip())
                    key="%s_%s" %(service_prefix,line.strip())
                if line.find("xx")!=-1 and line.find("_")!=-1: 
                    name="%s domain==%s and response code == %s" %(
                            service,
                            line.strip()[0:-4],
                            line.strip().split("_")[-1]
                        )
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("ms")!=-1 and line.find("_")==-1:
                    name="%s response time==(%s)" %(service,line.strip())
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("ms")!=-1 and  line.find("_")!=-1:
                    name="%s domain==%s and response time == (%s)" %(
                            service,
                            "_".join(line.strip().split("_")[0:-1]),
                            line.strip().split("_")[-1]
                        )
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("avgrt")!=-1 and line.find("_")==-1:
                    name="%s avg response time" %(service)
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("avgrt")!=-1 and  line.find("_")!=-1:
                    name="%s domain==%s and  avg response time" %(
                            service,
                            line.strip()[0:-6]
                    )
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("count")!=-1 and line.find("_")==-1:
                    name="%s count" %(service)
                    key="%s_%s" %(service_prefix,line.strip())

                if line.find("count")!=-1 and line.find("_")!=-1:
                    name="%s domain=%s and  count" %(service,line.strip()[0:-6])
                    key="%s_%s" %(service_prefix,line.strip())


                ##### some logic judgment end 
    
                params={
                    "name": name,
                    "key_": key,
                    "hostid": hostid,
                    "type": 2,
                    "value_type": 3,
                    "interfaceid": "",
                    "delay": 60
                }
                response=zb.item.create(params)
                print name
                print json.dumps(json.loads(response.text),indent=2)

hostid=get_host_id('Template Log Upload - httplog status')
add_item(hostid,service="upload",service_prefix="uploadhttpd",item_file="./item_file")
