 awk 'BEGIN{j=1}
        {
            if(FILENAME=="url")
            {
                temp=$1;
                gsub(/\//,"_",$1);
                a[temp]=$1
            }
            if(FILENAME=="response_code")
                b[j++]=$1;
        }
        END{
            for(k in a)
            { 
                for(l=1;l<=length(b);l++)
                print k,"rc",b[l]"\thello"a[k]"_"b[l]
            }
        }' url response_code
