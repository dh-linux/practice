from pyzabbix import zabbixapi
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"
url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def update_host(hostid):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.host.delete(["%s" % hostid])
    print json.dumps(json.loads(response.text),indent=2)


def get_hostid(host_name):
    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    rt=zb.host.get(
        {
            "output": "extend",
            "filter": {
                "host":["%s" % host_name]
            }
        })
    try:
        return json.loads(rt.text)["result"][0]["hostid"]
    except:
        return -1
    print json.dumps(json.loads(rt.text),indent=2)

host_list='svc120.weibo.imgbed.sx.sinanode.com svc121.weibo.imgbed.sx.sinanode.com svc122.weibo.imgbed.sx.sinanode.com svc123.weibo.imgbed.sx.sinanode.com svc125.weibo.imgbed.sx.sinanode.com svc126.weibo.imgbed.sx.sinanode.com svc127.weibo.imgbed.sx.sinanode.com svc128.weibo.imgbed.sx.sinanode.com svc129.weibo.imgbed.sx.sinanode.com svc130.weibo.imgbed.sx.sinanode.com svc131.weibo.imgbed.sx.sinanode.com svc132.weibo.imgbed.sx.sinanode.com svc133.weibo.imgbed.sx.sinanode.com svc134.weibo.imgbed.sx.sinanode.com svc135.weibo.imgbed.sx.sinanode.com svc137.weibo.imgbed.sx.sinanode.com svc138.weibo.imgbed.sx.sinanode.com svc139.weibo.imgbed.sx.sinanode.com svc140.weibo.imgbed.sx.sinanode.com svc141.weibo.imgbed.sx.sinanode.com upl100.weibo.imgbed.bx.sinanode.com upl101.weibo.imgbed.bx.sinanode.com upl102.weibo.imgbed.bx.sinanode.com upl103.weibo.imgbed.bx.sinanode.com upl104.weibo.imgbed.bx.sinanode.com upl105.weibo.imgbed.bx.sinanode.com upl106.weibo.imgbed.bx.sinanode.com upl107.weibo.imgbed.bx.sinanode.com upl108.weibo.imgbed.bx.sinanode.com upl109.weibo.imgbed.bx.sinanode.com upl110.weibo.imgbed.bx.sinanode.com upl111.weibo.imgbed.bx.sinanode.com upl112.weibo.imgbed.bx.sinanode.com upl113.weibo.imgbed.bx.sinanode.com upl114.weibo.imgbed.bx.sinanode.com upl115.weibo.imgbed.bx.sinanode.com upl116.weibo.imgbed.bx.sinanode.com upl117.weibo.imgbed.bx.sinanode.com upl118.weibo.imgbed.bx.sinanode.com upl119.weibo.imgbed.bx.sinanode.com upl120.weibo.imgbed.bx.sinanode.com upl122.weibo.imgbed.bx.sinanode.com upl123.weibo.imgbed.bx.sinanode.com upl125.weibo.imgbed.bx.sinanode.com upl126.weibo.imgbed.bx.sinanode.com upl128.weibo.imgbed.bx.sinanode.com upl129.weibo.imgbed.bx.sinanode.com upl130.weibo.imgbed.bx.sinanode.com upl131.weibo.imgbed.bx.sinanode.com upl132.weibo.imgbed.bx.sinanode.com upl133.weibo.imgbed.bx.sinanode.com'

for host in host_list.split():
    hostid=get_hostid(host)
    if hostid!=-1:
        print hostid,host
        update_host(hostid)
