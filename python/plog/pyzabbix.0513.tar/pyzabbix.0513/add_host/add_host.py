from pyzabbix import zabbixapi
import string
import json

url="http://10.210.71.145/zabbix/api_jsonrpc.php"
user="admin"
password="zabbix"

url="http://zbx001.weibo.imgbed.bx.sinanode.com/zabbix/api_jsonrpc.php"
user="baoning1"
password="1234qwer"

def get_group(group_name):

    global url,user,password
    zb=zabbixapi(url=url,user=user,password=password)
    response=zb.hostgroup.get(
            {
                "output":"extend",
                "filter":{
                    "name":[group_name]
                }
            })

    print group_name
    return json.loads(response.text)["result"][0]["groupid"]

def add_host(hostgroup,host_name):

    global url,user,password,group_list,proxyids

    zb=zabbixapi(url=url,user=user,password=password)
    location=host_name.split(".")[3]
    city=group_list[location]
    proxy_hostid=proxyids[location]

    import commands
    ip=commands.getoutput("dig +short %s" % host_name)

    add_group=[]
    add_group.append({"groupid":get_group(hostgroup)})
    add_group.append({"groupid":get_group(hostgroup+" "+city)})


    interfaces={
            "type": 1,
            "main": 1,
            "useip": 1,
            "ip": "%s" % ip,
            "dns": "",
            "port": "10050"
        }

    response=zb.host.create(
                {
                    "host": "%s" % host_name ,
                    "interfaces":[interfaces],
                    "proxy_hostid":proxy_hostid,
                    "groups":add_group,
                })
    print json.dumps(json.loads(response.text),indent=2)

proxyids={
        "bx":"15089",
        "gz":"14686",
        "sx":"14686",
        "yz":"15089",
        "hy":"15091"
}
group_list={
        "bx":"Beijing",
        "gz":"Guangzhou",
        "sx":"Guangzhou",
        "yz":"Beijing",
        "hy":"Tianjin"
}
hostgroup="Sina Weibo NotFs"
with open("./host_list") as f:
    while 1:
        line=f.readline()
        if not line:
            break
        else:
            host_name=line.strip()
            add_host(hostgroup,host_name)
