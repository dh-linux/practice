from plog.source.base import source_base
from plog.source.base import source_base
import os
import time
class source(source_base):

    def __init__(self,source_dict):
        """
        source_dict  come from the configure file
        which contain the configure info you  write
        """

    def yield_line(self):
        """
            complete youself
            only one rules
            you should 
        """
        yield line
