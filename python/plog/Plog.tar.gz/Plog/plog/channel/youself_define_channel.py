from plog.channel.base import channel_base
from plog.channel.base import channel_base
import os
import time
import re

class channel(channel_base):

    def __init__(self,channel_dict,source_iter,dict_queue):
        #this atrr must be exist
        self.dict_queue         = dict_queue
        #youself attr
    
    def parse_line(self):
        '''
        #this code mush be exist
        self.dict_queue.put(dict)
        '''
        '''
            you code here
        '''

    def youself_define_func(self):
        pass
