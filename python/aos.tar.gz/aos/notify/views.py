# -*- coding:utf-8 -*-

# django library
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect,HttpResponseBadRequest
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login as auth_login ,logout as auth_logout
from django.utils.translation import ugettext_lazy as _
import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.contrib.auth.decorators import login_required


# our own code
from django.db.models import Q
from issue.models import Issue
#from authority.models import Permission,product2AuthStr
from authority.decorators import permission_required


def checknotice(request, user_id):
    try:
        assigned_count = Issue.objects.filter(Q(assign_user = request.user.username), ~Q(status=8), ~Q(status=-1)).count()
        open_count = Issue.objects.filter(Q(create_user = request.user.username), ~Q(status=8), ~Q(status=-1)).count()
    except Exception, e:
        msg = e
        return HttpResponse(simplejson.dumps({"status":"1", "msg":"msg"}), content_type = "application/json")
    return HttpResponse(simplejson.dumps({"status":"0", "msg":{"assigned_count": assigned_count, "open_count": open_count}}) , content_type = "application/json")

def issuebymecount(request, user_id):
    try:
        print 'username', request.user.id
        c = Issue.objects.filter( Q(create_user = request.user.username), ~Q(status=7), ~Q(status=-1)).count()
    except:
        c = 0
        return HttpResponse(simplejson.dumps({"status":"0", "count":c}), content_type = "application/json")
    return HttpResponse(simplejson.dumps({"status":"1", "count":c}), content_type = "application/json")

def issuecount(request):
    try:
        c = Issue.objects.all().count()
    except:
        c = 0
        return HttpResponse(simplejson.dumps({"status":"0", "count":c}), content_type = "application/json")
    return HttpResponse(simplejson.dumps({"status":"1", "count":c}), content_type = "application/json")
