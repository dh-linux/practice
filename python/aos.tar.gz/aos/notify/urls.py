from django.conf.urls import patterns
from django.conf.urls import url

urlpatterns = patterns('',
    url(r'^checknotice/(?P<user_id>\d+)/$', 'notify.views.checknotice',name="check_notice"),
    
)
