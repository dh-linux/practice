# -*- coding:utf-8 -*-

# django library
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect,HttpResponseBadRequest
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login as auth_login ,logout as auth_logout
from django.utils.translation import ugettext_lazy as _
import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.contrib.auth.decorators import login_required


# our own code
from productline.models import Productline
from authority.models import Permission,productline2AuthStr
from authority.decorators import permission_required


# 显示用户列表
@permission_required('config_manage')
def index(request):
    items = Productline.objects.all()
    paginator = Paginator(items, 10)
    currentPage = int(request.POST.get('pageNum', 1))
    try:
        pager = paginator.page(currentPage)
    except InvalidPage:
        pager = paginator.page(1)
    after = 3
    before = 3
    lastPage = paginator.page_range[-1]
    if currentPage >= after:
        page_range = paginator.page_range[currentPage - after : currentPage + before]
    else:
        page_range = paginator.page_range[0 : currentPage + before]
        
    return render_to_response('productline/index.html',{'productline_list':pager, 'page_range': page_range, 'last_page':lastPage}, context_instance=RequestContext(request))
    
@permission_required('config_manage')
def add(request):
    if request.POST:
        productline_name = request.POST.get("name")
        productline_desc = request.POST.get("desc")
        productline_admin = request.POST.get("admin")
        
        #　保存区域信息
        productline = Productline();
        productline.name = productline_name
        productline.desc = productline_desc
	productline.admin = productline_admin
        productline.save()
        
        # 生成对应的权限字段
        #p = Permission()
        #p.codename = productline2AuthStr(productline.id)
        #p.desc = productline.name + u'产品线管理权限'
        #p.type = 4
        #p.save()
        
        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/productline/index", "message":u'添加成功'}), content_type='application/json')
    return render_to_response('productline/add.html')

@permission_required('config_manage') 
def edit(request, productline_id):
    productline = None
    try:
        productline = Productline.objects.get(id=int(productline_id))
    except BaseException:
        return HttpResponse(simplejson.dumps({"statusCode":400, "message":u'区域不存在!'}), content_type='application/json')
    if request.POST:
        productline.name = request.POST.get('name')
        productline.desc = request.POST.get("desc")
        productline.admin = request.POST.get("admin")
        productline.save()

        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/productline/index", "message":u'编辑成功'}), content_type='application/json')
    return render_to_response('productline/edit.html', {'productline':productline}) 


