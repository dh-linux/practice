#!usr/bin/env python
#coding: utf-8
from django.conf.urls import patterns
from django.conf.urls import url

urlpatterns = patterns('',
    url(r'^$', 'productline.views.index',name="productline"),
    url(r'^index/$', 'productline.views.index', name="productline_index"),
    url(r'^add/$', 'productline.views.add',name="productline_add"),
    url(r'^edit/(?P<productline_id>\d+)/$', 'productline.views.edit',name="productline_edit"),
)
