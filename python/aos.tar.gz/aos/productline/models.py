# -*- coding:utf-8 -*-
from django.db import models

# our own code
from django.contrib.auth.models import User


# 产品线 
class Productline(models.Model):
    # 重新定义表名
    class Meta:
        db_table = 'productline'
    # 主键由Django生成
    # 名称
    name = models.CharField(max_length=128) 
    desc = models.CharField(max_length=256)
    
    admin = models.CharField(max_length=64)
    users = models.ManyToManyField(User) 
    


