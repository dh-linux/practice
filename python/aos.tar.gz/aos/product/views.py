# -*- coding:utf-8 -*-

# django library
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect,HttpResponseBadRequest
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login as auth_login ,logout as auth_logout
from django.utils.translation import ugettext_lazy as _
import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.contrib.auth.decorators import login_required


# our own code
from product.models import Product
from productline.models import Productline
from iplist.models import Iplist
#from authority.models import Permission,product2AuthStr
from authority.decorators import permission_required


@permission_required('config_manage')
def index(request):
    items = Product.objects.all()
    paginator = Paginator(items, 10)
    currentPage = int(request.POST.get('pageNum', 1))
    try:
        pager = paginator.page(currentPage)
    except InvalidPage:
        pager = paginator.page(1)
    after = 3
    before = 3
    lastPage = paginator.page_range[-1]
    if currentPage >= after:
        page_range = paginator.page_range[currentPage - after : currentPage + before]
    else:
        page_range = paginator.page_range[0 : currentPage + before]
    return render_to_response('product/index.html',{'product_list':pager, 'page_range':page_range, 'last_page':lastPage}, context_instance=RequestContext(request))
   
@permission_required('config_manage')
def search(request):
    if request.POST:
        product_list = product.objects.all()
        
        if 'query' in request.POST and request.POST['query']:
            query = request.POST['query'].strip()
            product_list = product.objects.filter(product_name__icontains=query)
        paginator = Paginator(product_list, 10)
        currentPage = request.Post.get('pageNum', 1)
        try:
            pager = paginator.page(currentPage)
        except InvalidPage:
            pager = paginator.page(1)
        return render_to_response('product/search.html', {'product_list': pager})
    else:
        return HttpResponseBadRequest("Bad Request!")

@permission_required('config_manage')
def add(request):
    productline_list = Productline.objects.all()
    ip_list = Iplist.objects.all()
    if request.POST:
        productname = request.POST.get("productname").strip()
        productdesc = request.POST.get("productdesc").strip()
        productline_id = request.POST.get("productline_id").strip()
        svnpath = request.POST.get("svnpath").strip()
        rsyncpath = request.POST.get("rsyncpath").strip()
	while rsyncpath[-1] == '/':
            rsyncpath = rsyncpath[:-1]
        while rsyncpath[0] == '/':
            rsyncpath = rsyncpath[1:]

	rsyncport = request.POST.get("rsyncport").strip()
        simulationip = request.POST.getlist("simulationip")
        onlineip = request.POST.getlist("onlineip")
        needsimu = request.POST.get("needsimu").strip()
        #　保存项目信息
        product = Product()
        product.productname = productname
        product.productdesc = productdesc
        product.productline_id = productline_id
        product.svnpath = svnpath
        product.rsyncpath = rsyncpath
        product.rsyncport = rsyncport
        product.needsimu = needsimu
        product.save()

        #product.simulationip_set.clear()
        
        for item in simulationip:
            product.simulationip.add(int(item))
        
        #product.onlineip_set.clear()
        for item in onlineip:
            product.onlineip.add(int(item))
        product.save()
        
        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/product/index", "message":u'添加成功'}), content_type='application/json')
    return render_to_response('product/add.html',{'productline_list':productline_list, 'ip_list': ip_list},context_instance=RequestContext(request))

@permission_required('config_manage') 
def edit(request, product_id):
    ip_list = Iplist.objects.all()
    productline_list = Productline.objects.all()
    
    try:
        product = Product.objects.get(id=int(product_id))
        onlineips = product.onlineip.all()
        online_ids = []
        for ip in onlineips:
            online_ids.append(ip.id)
        simulationips = product.simulationip.all()
        simulation_ids = []
        for ip in simulationips:
            simulation_ids.append(ip.id)
    except BaseException,e :
        return HttpResponse(simplejson.dumps({"statusCode":400, "message":u'项目不存在!'}), content_type='application/json')

    if request.POST:
        product.productname = request.POST.get('productname')
        product.productdesc = request.POST.get("productdesc").strip()
        product.productline_id = request.POST.get("productline_id").strip()
        product.svnpath = request.POST.get("svnpath").strip()
        product.rsyncpath = request.POST.get("rsyncpath").strip()
        while product.rsyncpath[-1] == '/':
            product.rsyncpath = product.rsyncpath[:-1]
        while product.rsyncpath[0] == '/':
            product.rsyncpath = product.rsyncpath[1:]
        product.rsyncport = request.POST.get("rsyncport").strip()
        product.needsimu = request.POST.get("needsimu").strip()
        
        simulationip = request.POST.getlist("simulationip")
        onlineip = request.POST.getlist("onlineip")
        
        product.save()
        product.simulationip.clear()
        for item in simulationip:
            product.simulationip.add(int(item))
        
        product.onlineip.clear() 
        for item in onlineip:
            product.onlineip.add(int(item))
 
        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/product/index", "message":u'编辑成功'}), content_type='application/json')
    return render_to_response('product/edit.html', {'product':product, 'productline_list':productline_list, 'ip_list': ip_list, 'online_ids': online_ids, 'simulation_ids': simulation_ids, 'online_ids': online_ids}) 

def getproduct(request, productline_id):
    try:
        products = Product.objects.filter(productline_id = productline_id)
        product_list = {}
        for item in products:
            product_list[item.id] = item.productname 
    except:
        return HttpResponse(simplejson.dumps({"status":"0", "product_list": product_list}), content_type = 'application/json')
    return HttpResponse(simplejson.dumps({"status":"1", "product_list":product_list}), content_type = 'application/json')
