#!usr/bin/env python
#coding: utf-8
from django.conf.urls import patterns
from django.conf.urls import url

urlpatterns = patterns('',
    url(r'^$', 'product.views.index',name="product"),
    url(r'^index/$', 'product.views.index', name="product_index"),
    url(r'^add/$', 'product.views.add',name="product_add"),
    url(r'^edit/(?P<product_id>\d+)/$', 'product.views.edit',name="product_edit"),
    url(r'^getproduct/(?P<productline_id>\d+)/$', 'product.views.getproduct',name="product_getproduct"),
)
