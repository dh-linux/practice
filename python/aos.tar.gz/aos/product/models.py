# -*- coding:utf-8 -*-
from django.db import models

# our own code
from productline.models import Productline
from iplist.models import Iplist
# 产品线 
class Product(models.Model):
    # 重新定义表名
    class Meta:
        db_table = 'product'
    # 主键由Django生成
    # 名称
    productname = models.CharField(max_length=64) 
    productdesc = models.CharField(max_length=256)

    svnpath = models.CharField(max_length=256)
    rsyncpath = models.CharField(max_length=256)
    rsyncport = models.IntegerField()
    rsyncmodel = models.CharField(max_length=64)
    
    simulationip = models.ManyToManyField(Iplist)
    onlineip = models.ManyToManyField(Iplist, related_name = "online")

    productline = models.ForeignKey(Productline)
    
    laststable = models.CharField(max_length=256)
    needsimu = models.IntegerField()


