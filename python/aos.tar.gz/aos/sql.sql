-- MySQL dump 10.15  Distrib 10.0.20-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: charisma
-- ------------------------------------------------------
-- Server version	10.0.20-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permission_group_id_689710a9a73b7457_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth__content_type_id_508cf46651277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add session',5,'add_session'),(14,'Can change session',5,'change_session'),(15,'Can delete session',5,'delete_session'),(16,'Can add site',6,'add_site'),(17,'Can change site',6,'change_site'),(18,'Can delete site',6,'delete_site'),(19,'Can add log entry',7,'add_logentry'),(20,'Can change log entry',7,'change_logentry'),(21,'Can delete log entry',7,'delete_logentry'),(22,'Can add log',8,'add_log'),(23,'Can change log',8,'change_log'),(24,'Can delete log',8,'delete_log'),(25,'Can add permission',9,'add_permission'),(26,'Can change permission',9,'change_permission'),(27,'Can delete permission',9,'delete_permission'),(28,'Can add user profile',10,'add_userprofile'),(29,'Can change user profile',10,'change_userprofile'),(30,'Can delete user profile',10,'delete_userprofile'),(31,'Can add role',11,'add_role'),(32,'Can change role',11,'change_role'),(33,'Can delete role',11,'delete_role'),(34,'Can add area',12,'add_area'),(35,'Can change area',12,'change_area'),(36,'Can delete area',12,'delete_area'),(37,'Can add product',13,'add_product'),(38,'Can change product',13,'change_product'),(39,'Can delete product',13,'delete_product'),(40,'Can add productline',14,'add_productline'),(41,'Can change productline',14,'change_productline'),(42,'Can delete productline',14,'delete_productline'),(43,'Can add issue',15,'add_issue'),(44,'Can change issue',15,'change_issue'),(45,'Can delete issue',15,'delete_issue'),(46,'Can add iplist',16,'add_iplist'),(47,'Can change iplist',16,'change_iplist'),(48,'Can delete iplist',16,'delete_iplist'),(49,'Can add config',17,'add_config'),(50,'Can change config',17,'change_config'),(51,'Can delete config',17,'delete_config');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$20000$VSdQtFJzexOV$JV1ykrtE6T8E8aMubsZhHWG6PNdYhabuU6+HhnyX/HI=','2015-06-23 23:43:22',1,'admin','','','admin@admin.com',1,1,'2015-05-29 06:40:41'),(2,'default',NULL,0,'tanlong','','','tanlong@staff.sina.com.cn',0,1,'2015-06-01 00:15:50'),(3,'default',NULL,0,'t','','','t@t.com',0,1,'2015-06-01 00:57:20');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissi_user_id_7f0938558328534a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `svnuser` varchar(32) DEFAULT NULL,
  `svnpasswd` varchar(32) DEFAULT NULL,
  `codepath` varchar(256) DEFAULT NULL,
  `mailserver` varchar(64) DEFAULT NULL,
  `mailport` varchar(32) DEFAULT NULL,
  `mailuser` varchar(32) DEFAULT NULL,
  `mailpasswd` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'aos','A1B2C3@mop','/tmp/sinawap/aoscode/','mail.staff.sina.com.cn','5','aos','A1B2C3@mop');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `djang_content_type_id_697914295151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` (`user_id`),
  CONSTRAINT `djang_content_type_id_697914295151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_45f3b1d93ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (10,'account','userprofile'),(7,'admin','logentry'),(12,'area','area'),(2,'auth','group'),(1,'auth','permission'),(3,'auth','user'),(9,'authority','permission'),(17,'config','config'),(4,'contenttypes','contenttype'),(16,'iplist','iplist'),(15,'issue','issue'),(8,'log','log'),(13,'product','product'),(14,'productline','productline'),(11,'role','role'),(5,'sessions','session'),(6,'sites','site');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2015-05-29 06:40:17'),(2,'auth','0001_initial','2015-05-29 06:40:21'),(3,'admin','0001_initial','2015-05-29 06:40:22'),(4,'contenttypes','0002_remove_content_type_name','2015-05-29 06:40:23'),(5,'auth','0002_alter_permission_name_max_length','2015-05-29 06:40:23'),(6,'auth','0003_alter_user_email_max_length','2015-05-29 06:40:24'),(7,'auth','0004_alter_user_username_opts','2015-05-29 06:40:24'),(8,'auth','0005_alter_user_last_login_null','2015-05-29 06:40:24'),(9,'auth','0006_require_contenttypes_0002','2015-05-29 06:40:24'),(10,'sessions','0001_initial','2015-05-29 06:40:25'),(11,'sites','0001_initial','2015-05-29 06:40:25'),(12,'account','0001_initial','2015-05-29 06:43:19'),(13,'productline','0001_initial','2015-05-29 07:06:01'),(14,'product','0001_initial','2015-05-29 07:06:20'),(15,'issue','0001_initial','2015-05-29 16:42:48'),(16,'iplist','0001_initial','2015-05-31 15:58:00'),(17,'iplist','0002_auto_20150531_1616','2015-05-31 16:16:46'),(18,'issue','0002_auto_20150601_0009','2015-06-01 00:09:49'),(19,'config','0001_initial','2015-06-21 07:30:16'),(20,'config','0002_auto_20150623_0435','2015-06-23 04:35:35');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('16r6w7jsohp9m5zq3ak9y31ylai6wygg','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-15 00:38:44'),('1rxvmgt74uf8b0zzm62jyeh0ldpobtm8','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-29 18:57:24'),('1tyq4nzm1jgxht0b7wdekasz4e3bcxqi','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-12 09:14:54'),('2byhmsl8o6pm3v673rd5chsuyou4pokh','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-07 20:55:44'),('dnhc6ovd9eqjm15sz0tvbcb6m1umb6zf','N2NiMmU1ZWQ1MjMyY2FiMTU0MWJjMGE0NTMzZjlkNjk4NzI1ZTI3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-28 09:14:16'),('fcefz1412ir6qr5scg9p6b10megy8x94','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-12 15:21:48'),('h7cmoyaddcg8ilh6r1uljpc2xeq7hz0g','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-03 17:37:40'),('i2ybyhxue6hhesffb6bhd5ecrbdj1byf','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-05 11:57:33'),('im96f8v61282m9lb6oiint256n7zlq6m','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-28 09:09:44'),('j0g2r3l0o6chnou80awefehpy6r5qfga','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-01 11:23:28'),('nqurl65pwqnxyw1fn4ghkbm32lrawnjz','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-12 07:22:42'),('oj2jldnwtf0u3z43cb1b2don2bog06fq','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-07 23:43:22'),('qpnaqbc32r7icks7kl5vp8o0w72rcha9','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-04 10:54:17'),('tbp2t64ofx8uehzvrmd0rd6xumje5il1','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-29 22:59:40'),('tiajr84c10n0k5ofg0kctn26wirtiz7e','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-01 20:50:41'),('vwf5o2o4wc0r4rjyrdjkslnok13agnee','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-03 11:51:12'),('vyw3u29jlypza5rnhsbs8nju1o6a4g2w','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-07 03:36:36'),('wfnbadhh09c6bpyumms607kqi8te31p9','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-06-14 23:24:11'),('xzaaopshgj00k2jssil00zuf1f009378','YzMxNDc5YjJhY2ZlNzBlZTdhYzQ4M2JlYWE4MGZkOTE2ZWFmOTkwODp7Il9hdXRoX3VzZXJfaGFzaCI6IjhlNzBiODQ0NTAzMWI3OTlmM2NjMGI5NDEwMDQ0OTlmOWM2MWRlNjMiLCJwZXJtaXNzaW9uX2lkX2xpc3QiOltdLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiYXV0aG9yaXR5X3NldCI6WyJzeXN0ZW1fbWFuYWdlIiwidXNlcl9tYW5hZ2UiLCJyb2xlX21hbmFnZSIsImF1dGhvcml0eV9tYW5hZ2UiLCJjb25maWdfbWFuYWdlIl19','2015-07-07 23:31:24');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iplist`
--

DROP TABLE IF EXISTS `iplist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iplist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(32) NOT NULL,
  `iplist` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iplist`
--

LOCK TABLES `iplist` WRITE;
/*!40000 ALTER TABLE `iplist` DISABLE KEYS */;
INSERT INTO `iplist` VALUES (1,'浪首接口仿真机','172.16.181.78'),(2,'浪首接口线上机','172.16.88.42'),(3,'4','202.201.0.4'),(4,'6','202.201.0.3'),(5,'1','202.201.0.131\r\n202.201.0.213\r\n202.202.0.320');
/*!40000 ALTER TABLE `iplist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue`
--

DROP TABLE IF EXISTS `issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rt_id` int(11) DEFAULT NULL,
  `rt_status` varchar(64) DEFAULT NULL,
  `issue_title` varchar(256) NOT NULL,
  `issue_content` longtext,
  `lock` varchar(32) NOT NULL,
  `product_name_id` int(11) NOT NULL,
  `environment` varchar(32) DEFAULT NULL,
  `create_user` varchar(32) DEFAULT NULL,
  `test_user` varchar(32) DEFAULT NULL,
  `assign_user` varchar(32) DEFAULT NULL,
  `createdate` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `status` int(11) NOT NULL,
  `msg` longtext,
  `code_version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_product_name_id_245469382746abfb_fk_product_id` (`product_name_id`),
  CONSTRAINT `issue_product_name_id_245469382746abfb_fk_product_id` FOREIGN KEY (`product_name_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue`
--

LOCK TABLES `issue` WRITE;
/*!40000 ALTER TABLE `issue` DISABLE KEYS */;
INSERT INTO `issue` VALUES (1,NULL,NULL,'ping','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-18 02:00:41','2015-06-18 02:00:41',2,'PING baidu.com (123.125.114.144) 56(84) bytes of data.\n64 bytes from 123.125.114.144: icmp_seq=1 ttl=54 time=6.29 ms\n64 bytes from 123.125.114.144: icmp_seq=2 ttl=54 time=10.8 ms\n64 bytes from 123.125.114.144: icmp_seq=3 ttl=54 time=8.32 ms\n64 bytes from 123.125.114.144: icmp_seq=4 ttl=54 time=51.6 ms\n64 bytes from 123.125.114.144: icmp_seq=5 ttl=54 time=3.06 ms\n64 bytes from 123.125.114.144: icmp_seq=6 ttl=54 time=2.64 ms\n64 bytes from 123.125.114.144: icmp_seq=7 ttl=54 time=13.3 ms\n64 bytes from 123.125.114.144: icmp_seq=8 ttl=54 time=45.3 ms\n64 bytes from 123.125.114.144: icmp_seq=9 ttl=54 time=3.63 ms\n64 bytes from 123.125.114.144: icmp_seq=10 ttl=54 time=3.09 ms\n64 bytes from 123.125.114.144: icmp_seq=11 ttl=54 time=2.93 ms\n64 bytes from 123.125.114.144: icmp_seq=12 ttl=54 time=4.18 ms\n64 bytes from 123.125.114.144: icmp_seq=13 ttl=54 time=2.76 ms\n64 bytes from 123.125.114.144: icmp_seq=14 ttl=54 time=2.94 ms\n64 bytes from 123.125.114.144: icmp_seq=15 ttl=54 time=2.75 ms\n64 bytes from 123.125.114.144: icmp_seq=16 ttl=54 time=3.32 ms\n64 bytes from 123.125.114.144: icmp_seq=17 ttl=54 time=3.18 ms\n64 bytes from 123.125.114.144: icmp_seq=18 ttl=54 time=2.98 ms\n64 bytes from 123.125.114.144: icmp_seq=19 ttl=54 time=3.12 ms\n64 bytes from 123.125.114.144: icmp_seq=20 ttl=54 time=3.07 ms\n\n',NULL),(2,NULL,NULL,'PING test','测试PING','unLock',3,'仿真环境','admin','admin','admin','2015-06-18 07:44:34','2015-06-18 07:44:34',6,'PING baidu.com (180.149.132.47) 56(84) bytes of data.64 bytes from 180.149.132.47: icmp_seq=1 ttl=44 time=121 ms64 bytes from 180.149.132.47: icmp_seq=2 ttl=44 time=138 ms64 bytes from 180.149.132.47: icmp_seq=3 ttl=44 time=128 ms64 bytes from 180.149.132.47: icmp_seq=4 ttl=44 time=114 ms64 bytes from 180.149.132.47: icmp_seq=5 ttl=44 time=119 ms64 bytes from 180.149.132.47: icmp_seq=6 ttl=44 time=121 ms64 bytes from 180.149.132.47: icmp_seq=7 ttl=44 time=118 ms64 bytes from 180.149.132.47: icmp_seq=8 ttl=44 time=126 ms64 bytes from 180.149.132.47: icmp_seq=9 ttl=44 time=115 ms64 bytes from 180.149.132.47: icmp_seq=10 ttl=44 time=113 ms64 bytes from 180.149.132.47: icmp_seq=11 ttl=44 time=115 ms64 bytes from 180.149.132.47: icmp_seq=12 ttl=44 time=122 ms64 bytes from 180.149.132.47: icmp_seq=13 ttl=44 time=115 ms64 bytes from 180.149.132.47: icmp_seq=14 ttl=44 time=111 ms64 bytes from 180.149.132.47: icmp_seq=15 ttl=44 time=111 ms64 bytes from 180.149.132.47: icmp_seq=16 ttl=44 time=117 ms64 bytes from 180.149.132.47: icmp_seq=17 ttl=44 time=110 ms64 bytes from 180.149.132.47: icmp_seq=18 ttl=44 time=115 ms64 bytes from 180.149.132.47: icmp_seq=19 ttl=44 time=112 ms64 bytes from 180.149.132.47: icmp_seq=20 ttl=44 time=115 ms',NULL),(3,NULL,NULL,'dfsa','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-18 07:50:30','2015-06-18 07:50:30',6,'PING baidu.com (220.181.57.217) 56(84) bytes of data.64 bytes from 220.181.57.217: icmp_seq=1 ttl=44 time=111 ms64 bytes from 220.181.57.217: icmp_seq=2 ttl=44 time=110 ms64 bytes from 220.181.57.217: icmp_seq=3 ttl=44 time=115 ms64 bytes from 220.181.57.217: icmp_seq=4 ttl=44 time=104 ms64 bytes from 220.181.57.217: icmp_seq=5 ttl=44 time=104 ms64 bytes from 220.181.57.217: icmp_seq=6 ttl=44 time=109 ms64 bytes from 220.181.57.217: icmp_seq=7 ttl=44 time=110 ms64 bytes from 220.181.57.217: icmp_seq=8 ttl=44 time=115 ms64 bytes from 220.181.57.217: icmp_seq=9 ttl=44 time=109 ms64 bytes from 220.181.57.217: icmp_seq=10 ttl=44 time=115 ms64 bytes from 220.181.57.217: icmp_seq=11 ttl=44 time=110 ms64 bytes from 220.181.57.217: icmp_seq=12 ttl=44 time=114 ms64 bytes from 220.181.57.217: icmp_seq=13 ttl=44 time=113 ms64 bytes from 220.181.57.217: icmp_seq=14 ttl=44 time=110 ms64 bytes from 220.181.57.217: icmp_seq=15 ttl=44 time=106 ms64 bytes from 220.181.57.217: icmp_seq=16 ttl=44 time=106 ms64 bytes from 220.181.57.217: icmp_seq=17 ttl=44 time=109 ms64 bytes from 220.181.57.217: icmp_seq=18 ttl=44 time=105 ms64 bytes from 220.181.57.217: icmp_seq=19 ttl=44 time=110 ms64 bytes from 220.181.57.217: icmp_seq=20 ttl=44 time=110 ms',NULL),(4,NULL,NULL,'ping test','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-18 09:43:35','2015-06-18 09:43:35',6,'PING baidu.com (123.125.114.144) 56(84) bytes of data.64 bytes from 123.125.114.144: icmp_seq=1 ttl=54 time=3.49 ms64 bytes from 123.125.114.144: icmp_seq=2 ttl=54 time=5.60 ms64 bytes from 123.125.114.144: icmp_seq=3 ttl=54 time=3.35 ms64 bytes from 123.125.114.144: icmp_seq=4 ttl=54 time=3.02 ms64 bytes from 123.125.114.144: icmp_seq=5 ttl=54 time=8.55 ms64 bytes from 123.125.114.144: icmp_seq=6 ttl=54 time=3.49 ms64 bytes from 123.125.114.144: icmp_seq=7 ttl=54 time=3.36 ms64 bytes from 123.125.114.144: icmp_seq=8 ttl=54 time=3.86 ms64 bytes from 123.125.114.144: icmp_seq=9 ttl=54 time=3.08 ms64 bytes from 123.125.114.144: icmp_seq=10 ttl=54 time=6.70 ms64 bytes from 123.125.114.144: icmp_seq=11 ttl=54 time=2.91 ms64 bytes from 123.125.114.144: icmp_seq=12 ttl=54 time=3.03 ms64 bytes from 123.125.114.144: icmp_seq=13 ttl=54 time=5.79 ms64 bytes from 123.125.114.144: icmp_seq=14 ttl=54 time=5.76 ms64 bytes from 123.125.114.144: icmp_seq=15 ttl=54 time=3.25 ms64 bytes from 123.125.114.144: icmp_seq=16 ttl=54 time=5.38 ms64 bytes from 123.125.114.144: icmp_seq=17 ttl=54 time=3.67 ms64 bytes from 123.125.114.144: icmp_seq=18 ttl=54 time=3.00 ms64 bytes from 123.125.114.144: icmp_seq=19 ttl=54 time=2.78 ms64 bytes from 123.125.114.144: icmp_seq=20 ttl=54 time=2.98 ms',NULL),(5,NULL,NULL,'ping','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-18 10:26:25','2015-06-18 10:26:25',6,'PING baidu.com (123.125.114.144) 56(84) bytes of data.\n64 bytes from 123.125.114.144: icmp_seq=1 ttl=54 time=3.37 ms\n64 bytes from 123.125.114.144: icmp_seq=2 ttl=54 time=4.47 ms\n64 bytes from 123.125.114.144: icmp_seq=3 ttl=54 time=2.91 ms\n64 bytes from 123.125.114.144: icmp_seq=4 ttl=54 time=3.27 ms\n64 bytes from 123.125.114.144: icmp_seq=5 ttl=54 time=3.26 ms\n64 bytes from 123.125.114.144: icmp_seq=6 ttl=54 time=3.62 ms\n64 bytes from 123.125.114.144: icmp_seq=7 ttl=54 time=3.49 ms\n64 bytes from 123.125.114.144: icmp_seq=8 ttl=54 time=2.79 ms\n64 bytes from 123.125.114.144: icmp_seq=9 ttl=54 time=3.35 ms\n64 bytes from 123.125.114.144: icmp_seq=10 ttl=54 time=9.74 ms\n64 bytes from 123.125.114.144: icmp_seq=11 ttl=54 time=5.55 ms\n64 bytes from 123.125.114.144: icmp_seq=12 ttl=54 time=4.27 ms\n64 bytes from 123.125.114.144: icmp_seq=13 ttl=54 time=4.47 ms\n64 bytes from 123.125.114.144: icmp_seq=14 ttl=54 time=4.66 ms\n64 bytes from 123.125.114.144: icmp_seq=15 ttl=54 time=4.85 ms\n64 bytes from 123.125.114.144: icmp_seq=16 ttl=54 time=3.45 ms\n64 bytes from 123.125.114.144: icmp_seq=17 ttl=54 time=2.75 ms\n64 bytes from 123.125.114.144: icmp_seq=18 ttl=54 time=3.10 ms\n64 bytes from 123.125.114.144: icmp_seq=19 ttl=54 time=7.08 ms\n64 bytes from 123.125.114.144: icmp_seq=20 ttl=54 time=4.80 ms\n',NULL),(6,NULL,NULL,'1111','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-18 11:21:09','2015-06-18 11:21:09',6,'PING baidu.com (180.149.132.47) 56(84) bytes of data.\n64 bytes from 180.149.132.47: icmp_seq=1 ttl=55 time=7.08 ms\n64 bytes from 180.149.132.47: icmp_seq=2 ttl=55 time=4.78 ms\n64 bytes from 180.149.132.47: icmp_seq=3 ttl=55 time=4.80 ms\n64 bytes from 180.149.132.47: icmp_seq=4 ttl=55 time=4.84 ms\n64 bytes from 180.149.132.47: icmp_seq=5 ttl=55 time=5.37 ms\n64 bytes from 180.149.132.47: icmp_seq=6 ttl=55 time=4.64 ms\n64 bytes from 180.149.132.47: icmp_seq=7 ttl=55 time=12.1 ms\n64 bytes from 180.149.132.47: icmp_seq=8 ttl=55 time=5.89 ms\n64 bytes from 180.149.132.47: icmp_seq=9 ttl=55 time=4.57 ms\n64 bytes from 180.149.132.47: icmp_seq=10 ttl=55 time=4.82 ms\n64 bytes from 180.149.132.47: icmp_seq=11 ttl=55 time=4.66 ms\n64 bytes from 180.149.132.47: icmp_seq=12 ttl=55 time=5.33 ms\n64 bytes from 180.149.132.47: icmp_seq=13 ttl=55 time=4.57 ms\n64 bytes from 180.149.132.47: icmp_seq=14 ttl=55 time=5.05 ms\n64 bytes from 180.149.132.47: icmp_seq=15 ttl=55 time=13.5 ms\n64 bytes from 180.149.132.47: icmp_seq=16 ttl=55 time=14.7 ms\n64 bytes from 180.149.132.47: icmp_seq=17 ttl=55 time=7.76 ms\n64 bytes from 180.149.132.47: icmp_seq=18 ttl=55 time=9.56 ms\n64 bytes from 180.149.132.47: icmp_seq=19 ttl=55 time=4.68 ms\n64 bytes from 180.149.132.47: icmp_seq=20 ttl=55 time=4.55 ms\n\n',NULL),(7,NULL,NULL,'test','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-19 12:11:22','2015-06-19 12:11:22',2,'PING baidu.com (123.125.114.144) 56(84) bytes of data.\n64 bytes from 123.125.114.144: icmp_seq=1 ttl=54 time=2.36 ms\n64 bytes from 123.125.114.144: icmp_seq=2 ttl=54 time=3.38 ms\n64 bytes from 123.125.114.144: icmp_seq=3 ttl=54 time=3.22 ms\n64 bytes from 123.125.114.144: icmp_seq=4 ttl=54 time=2.65 ms\n64 bytes from 123.125.114.144: icmp_seq=5 ttl=54 time=3.02 ms\n64 bytes from 123.125.114.144: icmp_seq=6 ttl=54 time=3.17 ms\n64 bytes from 123.125.114.144: icmp_seq=7 ttl=54 time=3.91 ms\n64 bytes from 123.125.114.144: icmp_seq=8 ttl=54 time=3.23 ms\n64 bytes from 123.125.114.144: icmp_seq=9 ttl=54 time=3.35 ms\n64 bytes from 123.125.114.144: icmp_seq=10 ttl=54 time=3.92 ms\n64 bytes from 123.125.114.144: icmp_seq=11 ttl=54 time=2.86 ms\n64 bytes from 123.125.114.144: icmp_seq=12 ttl=54 time=3.66 ms\n64 bytes from 123.125.114.144: icmp_seq=13 ttl=54 time=2.62 ms\n64 bytes from 123.125.114.144: icmp_seq=14 ttl=54 time=4.39 ms\n64 bytes from 123.125.114.144: icmp_seq=15 ttl=54 time=5.13 ms\n64 bytes from 123.125.114.144: icmp_seq=16 ttl=54 time=14.5 ms\n64 bytes from 123.125.114.144: icmp_seq=17 ttl=54 time=4.86 ms\n64 bytes from 123.125.114.144: icmp_seq=18 ttl=54 time=2.83 ms\n64 bytes from 123.125.114.144: icmp_seq=19 ttl=54 time=2.61 ms\n64 bytes from 123.125.114.144: icmp_seq=20 ttl=54 time=2.85 ms\n',NULL),(8,NULL,NULL,'fa','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-19 12:12:57','2015-06-19 12:12:57',2,'PING baidu.com (123.125.114.144) 56(84) bytes of data.\n64 bytes from 123.125.114.144: icmp_seq=1 ttl=54 time=3.38 ms\n64 bytes from 123.125.114.144: icmp_seq=2 ttl=54 time=5.49 ms\n64 bytes from 123.125.114.144: icmp_seq=3 ttl=54 time=11.9 ms\n64 bytes from 123.125.114.144: icmp_seq=4 ttl=54 time=4.18 ms\n64 bytes from 123.125.114.144: icmp_seq=5 ttl=54 time=3.92 ms\n64 bytes from 123.125.114.144: icmp_seq=6 ttl=54 time=4.85 ms\n64 bytes from 123.125.114.144: icmp_seq=7 ttl=54 time=9.63 ms\n64 bytes from 123.125.114.144: icmp_seq=8 ttl=54 time=7.87 ms\n64 bytes from 123.125.114.144: icmp_seq=9 ttl=54 time=9.95 ms\n64 bytes from 123.125.114.144: icmp_seq=10 ttl=54 time=3.92 ms\n64 bytes from 123.125.114.144: icmp_seq=11 ttl=54 time=5.89 ms\n64 bytes from 123.125.114.144: icmp_seq=12 ttl=54 time=4.57 ms\n64 bytes from 123.125.114.144: icmp_seq=13 ttl=54 time=5.04 ms\n64 bytes from 123.125.114.144: icmp_seq=14 ttl=54 time=4.12 ms\n64 bytes from 123.125.114.144: icmp_seq=15 ttl=54 time=6.72 ms\n64 bytes from 123.125.114.144: icmp_seq=16 ttl=54 time=2.54 ms\n64 bytes from 123.125.114.144: icmp_seq=17 ttl=54 time=2.76 ms\n64 bytes from 123.125.114.144: icmp_seq=18 ttl=54 time=3.28 ms\n64 bytes from 123.125.114.144: icmp_seq=19 ttl=54 time=5.49 ms\n64 bytes from 123.125.114.144: icmp_seq=20 ttl=54 time=4.20 ms\n',NULL),(9,NULL,NULL,'111','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-19 12:16:42','2015-06-19 12:16:42',2,'PING baidu.com (220.181.57.217) 56(84) bytes of data.\n64 bytes from 220.181.57.217: icmp_seq=1 ttl=52 time=6.22 ms\n64 bytes from 220.181.57.217: icmp_seq=2 ttl=52 time=5.55 ms\n64 bytes from 220.181.57.217: icmp_seq=3 ttl=52 time=5.43 ms\n64 bytes from 220.181.57.217: icmp_seq=4 ttl=52 time=5.41 ms\n64 bytes from 220.181.57.217: icmp_seq=5 ttl=52 time=7.31 ms\n64 bytes from 220.181.57.217: icmp_seq=6 ttl=52 time=6.00 ms\n64 bytes from 220.181.57.217: icmp_seq=7 ttl=52 time=4.81 ms\n64 bytes from 220.181.57.217: icmp_seq=8 ttl=52 time=5.07 ms\n64 bytes from 220.181.57.217: icmp_seq=9 ttl=52 time=5.91 ms\n64 bytes from 220.181.57.217: icmp_seq=10 ttl=52 time=5.22 ms\n64 bytes from 220.181.57.217: icmp_seq=11 ttl=52 time=5.50 ms\n64 bytes from 220.181.57.217: icmp_seq=12 ttl=52 time=5.43 ms\n64 bytes from 220.181.57.217: icmp_seq=13 ttl=52 time=4.99 ms\n64 bytes from 220.181.57.217: icmp_seq=14 ttl=52 time=5.43 ms\n64 bytes from 220.181.57.217: icmp_seq=15 ttl=52 time=5.51 ms\n64 bytes from 220.181.57.217: icmp_seq=16 ttl=52 time=8.91 ms\n64 bytes from 220.181.57.217: icmp_seq=17 ttl=52 time=5.98 ms\n64 bytes from 220.181.57.217: icmp_seq=18 ttl=52 time=5.47 ms\n64 bytes from 220.181.57.217: icmp_seq=19 ttl=52 time=5.32 ms\n64 bytes from 220.181.57.217: icmp_seq=20 ttl=52 time=5.12 ms\n\n',NULL),(10,NULL,NULL,'ping','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-19 12:18:59','2015-06-19 12:18:59',2,'PING baidu.com (220.181.57.217) 56(84) bytes of data.\n64 bytes from 220.181.57.217: icmp_seq=1 ttl=52 time=6.56 ms\n64 bytes from 220.181.57.217: icmp_seq=2 ttl=52 time=5.08 ms\n64 bytes from 220.181.57.217: icmp_seq=3 ttl=52 time=5.92 ms\n64 bytes from 220.181.57.217: icmp_seq=4 ttl=52 time=5.52 ms\n64 bytes from 220.181.57.217: icmp_seq=5 ttl=52 time=5.53 ms\n64 bytes from 220.181.57.217: icmp_seq=6 ttl=52 time=6.42 ms\n64 bytes from 220.181.57.217: icmp_seq=7 ttl=52 time=5.97 ms\n64 bytes from 220.181.57.217: icmp_seq=8 ttl=52 time=50.0 ms\n64 bytes from 220.181.57.217: icmp_seq=9 ttl=52 time=8.26 ms\n64 bytes from 220.181.57.217: icmp_seq=10 ttl=52 time=29.2 ms\n64 bytes from 220.181.57.217: icmp_seq=11 ttl=52 time=52.0 ms\n64 bytes from 220.181.57.217: icmp_seq=12 ttl=52 time=74.8 ms\n64 bytes from 220.181.57.217: icmp_seq=13 ttl=52 time=36.9 ms\n64 bytes from 220.181.57.217: icmp_seq=14 ttl=52 time=7.03 ms\n64 bytes from 220.181.57.217: icmp_seq=15 ttl=52 time=5.85 ms\n64 bytes from 220.181.57.217: icmp_seq=16 ttl=52 time=5.41 ms\n64 bytes from 220.181.57.217: icmp_seq=17 ttl=52 time=5.98 ms\n64 bytes from 220.181.57.217: icmp_seq=18 ttl=52 time=5.85 ms\n64 bytes from 220.181.57.217: icmp_seq=19 ttl=52 time=7.05 ms\n64 bytes from 220.181.57.217: icmp_seq=20 ttl=52 time=5.52 ms\n\n',NULL),(11,NULL,NULL,'1','上线内容','unLock',2,'仿真环境','admin','1','1','2015-06-19 12:19:44','2015-06-19 12:19:44',2,'PING baidu.com (220.181.57.217) 56(84) bytes of data.\n64 bytes from 220.181.57.217: icmp_seq=1 ttl=52 time=5.17 ms\n64 bytes from 220.181.57.217: icmp_seq=2 ttl=52 time=5.48 ms\n64 bytes from 220.181.57.217: icmp_seq=3 ttl=52 time=5.66 ms\n64 bytes from 220.181.57.217: icmp_seq=4 ttl=52 time=5.29 ms\n64 bytes from 220.181.57.217: icmp_seq=5 ttl=52 time=5.27 ms\n64 bytes from 220.181.57.217: icmp_seq=6 ttl=52 time=5.59 ms\n64 bytes from 220.181.57.217: icmp_seq=7 ttl=52 time=5.18 ms\n64 bytes from 220.181.57.217: icmp_seq=8 ttl=52 time=5.71 ms\n64 bytes from 220.181.57.217: icmp_seq=9 ttl=52 time=5.42 ms\n64 bytes from 220.181.57.217: icmp_seq=10 ttl=52 time=5.48 ms\n64 bytes from 220.181.57.217: icmp_seq=11 ttl=52 time=9.65 ms\n64 bytes from 220.181.57.217: icmp_seq=12 ttl=52 time=6.46 ms\n64 bytes from 220.181.57.217: icmp_seq=13 ttl=52 time=5.30 ms\n64 bytes from 220.181.57.217: icmp_seq=14 ttl=52 time=4.89 ms\n64 bytes from 220.181.57.217: icmp_seq=15 ttl=52 time=8.00 ms\n64 bytes from 220.181.57.217: icmp_seq=16 ttl=52 time=5.22 ms\n64 bytes from 220.181.57.217: icmp_seq=17 ttl=52 time=5.37 ms\n64 bytes from 220.181.57.217: icmp_seq=18 ttl=52 time=5.15 ms\n64 bytes from 220.181.57.217: icmp_seq=19 ttl=52 time=5.23 ms\n64 bytes from 220.181.57.217: icmp_seq=20 ttl=52 time=5.49 ms\n\n',NULL),(12,NULL,NULL,'fdsad','上线内容','unLock',2,'仿真环境','admin','fadsd','fadsd','2015-06-19 12:56:39','2015-06-19 12:56:39',2,'PING baidu.com (180.149.132.47) 56(84) bytes of data.\n64 bytes from 180.149.132.47: icmp_seq=1 ttl=55 time=6.69 ms\n64 bytes from 180.149.132.47: icmp_seq=2 ttl=55 time=6.92 ms\n64 bytes from 180.149.132.47: icmp_seq=3 ttl=55 time=85.8 ms\n64 bytes from 180.149.132.47: icmp_seq=4 ttl=55 time=9.39 ms\n64 bytes from 180.149.132.47: icmp_seq=5 ttl=55 time=7.17 ms\n64 bytes from 180.149.132.47: icmp_seq=6 ttl=55 time=4.32 ms\n64 bytes from 180.149.132.47: icmp_seq=7 ttl=55 time=4.11 ms\n64 bytes from 180.149.132.47: icmp_seq=8 ttl=55 time=4.52 ms\n64 bytes from 180.149.132.47: icmp_seq=9 ttl=55 time=4.36 ms\n64 bytes from 180.149.132.47: icmp_seq=10 ttl=55 time=4.23 ms\n64 bytes from 180.149.132.47: icmp_seq=11 ttl=55 time=4.70 ms\n64 bytes from 180.149.132.47: icmp_seq=12 ttl=55 time=5.00 ms\n64 bytes from 180.149.132.47: icmp_seq=13 ttl=55 time=4.39 ms\n64 bytes from 180.149.132.47: icmp_seq=14 ttl=55 time=5.11 ms\n64 bytes from 180.149.132.47: icmp_seq=15 ttl=55 time=4.01 ms\n64 bytes from 180.149.132.47: icmp_seq=16 ttl=55 time=4.84 ms\n64 bytes from 180.149.132.47: icmp_seq=17 ttl=55 time=4.86 ms\n64 bytes from 180.149.132.47: icmp_seq=18 ttl=55 time=4.28 ms\n64 bytes from 180.149.132.47: icmp_seq=19 ttl=55 time=4.93 ms\n64 bytes from 180.149.132.47: icmp_seq=20 ttl=55 time=4.01 ms\n\n',NULL),(13,NULL,NULL,'d','上线内容','unLock',2,'仿真环境','admin','d','d','2015-06-19 12:57:17','2015-06-19 12:57:17',2,'PING baidu.com (220.181.57.217) 56(84) bytes of data.\n64 bytes from 220.181.57.217: icmp_seq=1 ttl=52 time=5.43 ms\n64 bytes from 220.181.57.217: icmp_seq=2 ttl=52 time=5.53 ms\n64 bytes from 220.181.57.217: icmp_seq=3 ttl=52 time=5.91 ms\n64 bytes from 220.181.57.217: icmp_seq=4 ttl=52 time=5.91 ms\n64 bytes from 220.181.57.217: icmp_seq=5 ttl=52 time=5.76 ms\n64 bytes from 220.181.57.217: icmp_seq=6 ttl=52 time=5.61 ms\n64 bytes from 220.181.57.217: icmp_seq=7 ttl=52 time=5.61 ms\n64 bytes from 220.181.57.217: icmp_seq=8 ttl=52 time=5.46 ms\n64 bytes from 220.181.57.217: icmp_seq=9 ttl=52 time=7.63 ms\n64 bytes from 220.181.57.217: icmp_seq=10 ttl=52 time=5.30 ms\n64 bytes from 220.181.57.217: icmp_seq=11 ttl=52 time=5.55 ms\n64 bytes from 220.181.57.217: icmp_seq=12 ttl=52 time=5.09 ms\n64 bytes from 220.181.57.217: icmp_seq=13 ttl=52 time=5.16 ms\n64 bytes from 220.181.57.217: icmp_seq=14 ttl=52 time=5.35 ms\n64 bytes from 220.181.57.217: icmp_seq=15 ttl=52 time=5.18 ms\n64 bytes from 220.181.57.217: icmp_seq=16 ttl=52 time=5.14 ms\n64 bytes from 220.181.57.217: icmp_seq=17 ttl=52 time=5.61 ms\n64 bytes from 220.181.57.217: icmp_seq=18 ttl=52 time=6.08 ms\n64 bytes from 220.181.57.217: icmp_seq=19 ttl=52 time=5.97 ms\n64 bytes from 220.181.57.217: icmp_seq=20 ttl=52 time=5.33 ms\n\n',NULL),(14,NULL,NULL,'d','上线内容','unLock',2,'仿真环境','admin','d','d','2015-06-19 12:57:32','2015-06-19 12:57:32',2,'PING baidu.com (220.181.57.217) 56(84) bytes of data.\n64 bytes from 220.181.57.217: icmp_seq=1 ttl=52 time=5.33 ms\n64 bytes from 220.181.57.217: icmp_seq=2 ttl=52 time=5.98 ms\n64 bytes from 220.181.57.217: icmp_seq=3 ttl=52 time=5.50 ms\n64 bytes from 220.181.57.217: icmp_seq=4 ttl=52 time=5.32 ms\n64 bytes from 220.181.57.217: icmp_seq=5 ttl=52 time=8.81 ms\n64 bytes from 220.181.57.217: icmp_seq=6 ttl=52 time=5.06 ms\n64 bytes from 220.181.57.217: icmp_seq=7 ttl=52 time=5.30 ms\n64 bytes from 220.181.57.217: icmp_seq=8 ttl=52 time=6.80 ms\n64 bytes from 220.181.57.217: icmp_seq=9 ttl=52 time=5.12 ms\n64 bytes from 220.181.57.217: icmp_seq=10 ttl=52 time=7.03 ms\n64 bytes from 220.181.57.217: icmp_seq=11 ttl=52 time=5.47 ms\n64 bytes from 220.181.57.217: icmp_seq=12 ttl=52 time=5.09 ms\n64 bytes from 220.181.57.217: icmp_seq=13 ttl=52 time=5.90 ms\n64 bytes from 220.181.57.217: icmp_seq=14 ttl=52 time=7.70 ms\n64 bytes from 220.181.57.217: icmp_seq=15 ttl=52 time=4.94 ms\n64 bytes from 220.181.57.217: icmp_seq=16 ttl=52 time=5.20 ms\n64 bytes from 220.181.57.217: icmp_seq=17 ttl=52 time=5.57 ms\n64 bytes from 220.181.57.217: icmp_seq=18 ttl=52 time=5.74 ms\n64 bytes from 220.181.57.217: icmp_seq=19 ttl=52 time=5.87 ms\n64 bytes from 220.181.57.217: icmp_seq=20 ttl=52 time=5.21 ms\n\n',NULL),(15,NULL,NULL,'1','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-21 12:24:02','2015-06-21 12:24:02',-1,'\'QuerySet\' object has no attribute \'svnuser\'',NULL),(16,NULL,NULL,'1','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-21 12:31:19','2015-06-21 12:31:19',-1,'\'QuerySet\' object has no attribute \'svnuser\'',NULL),(17,NULL,NULL,'1','上线内容','unLock',2,'仿真环境','admin','1','admin','2015-06-23 03:49:50','2015-06-23 03:49:50',-1,'\'QuerySet\' object has no attribute \'svnuser\'',NULL),(18,NULL,NULL,'d','上线内容','unLock',2,'仿真环境','admin','1','admin','2015-06-23 03:55:46','2015-06-23 03:55:46',-1,'svn: E155010: The node \'/home/long/aos/svn_aos/1\' was not found.\n',NULL),(19,NULL,NULL,'1','上线内容','unLock',2,'仿真环境','admin','1','admin','2015-06-23 04:52:37','2015-06-23 04:52:37',-1,'svn: warning: W155010: The node \'/home/long/aos/svn_aos/1\' was not found.\n\nsvn: E200009: Could not display info for all targets because some targets don\'t exist\n',NULL),(20,NULL,NULL,'浪首接口测试','Just a simple test','unLock',2,'仿真环境','admin','admin','admin','2015-06-23 10:05:31','2015-06-23 10:05:31',-1,'svn: E200015: Unable to connect to a repository at URL \'https://svn1.intra.sina.com.cn/wapcms/wap_remoulds/api/trunk\'\nsvn: E200015: The operation was interrupted\n',NULL),(21,NULL,NULL,'浪首接口测试','上线内容','unLock',2,'仿真环境','admin','admin','admin','2015-06-23 10:06:57','2015-06-23 10:06:57',2,'172.16.88.42:rsync error: received SIGINT, SIGTERM, or SIGHUP (code 20) at rsync.c(632) [sender=3.1.1]\n',229728),(22,NULL,NULL,'1','上线内容','unLock',2,'仿真环境','admin','tanlong','tanlong','2015-06-23 23:46:08','2015-06-23 23:46:08',2,'172.16.88.42: 完成...',229728);
/*!40000 ALTER TABLE `issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` datetime NOT NULL,
  `username` varchar(64) NOT NULL,
  `content` varchar(255) NOT NULL,
  `log_type` int(11) NOT NULL,
  `relate_id` int(11) DEFAULT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
INSERT INTO `log` VALUES (1,'2015-05-29 06:41:15','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(2,'2015-05-29 06:58:18','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(3,'2015-05-29 06:58:23','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(4,'2015-05-29 07:19:53','admin','execute logout user success!',0,NULL,1),(5,'2015-05-29 07:19:56','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(6,'2015-05-29 07:21:20','admin','execute logout user success!',0,NULL,1),(7,'2015-05-29 07:21:23','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(8,'2015-05-29 07:21:36','admin','execute logout user success!',0,NULL,1),(9,'2015-05-29 07:21:39','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(10,'2015-05-29 07:22:39','admin','execute logout user success!',0,NULL,1),(11,'2015-05-29 07:22:42','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(12,'2015-05-29 09:14:54','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(13,'2015-05-29 15:21:48','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(14,'2015-05-31 09:49:39','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(15,'2015-05-31 23:24:11','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(16,'2015-05-31 23:36:09','admin','execute add role 系统管理员 success!',2,1,1),(17,'2015-05-31 23:40:46','admin','execute edit role config_mange success!',2,1,1),(18,'2015-05-31 23:41:01','admin','execute add role user_mange success!',2,2,1),(19,'2015-05-31 23:41:17','admin','execute edit role user_manage success!',2,2,1),(20,'2015-05-31 23:41:23','admin','execute edit role config_manage success!',2,1,1),(21,'2015-05-31 23:41:40','admin','execute add role authority_manage success!',2,3,1),(22,'2015-05-31 23:42:21','admin','execute add role system_manage success!',2,4,1),(23,'2015-05-31 23:43:12','admin','execute edit user admin success!',1,1,1),(24,'2015-05-31 23:45:29','admin','execute add role online_user success!',2,5,1),(25,'2015-05-31 23:47:22','admin','execute edit role developer success!',2,5,1),(26,'2015-05-31 23:47:33','admin','execute add role tester success!',2,6,1),(27,'2015-05-31 23:48:07','admin','execute add role productline_mange success!',2,7,1),(28,'2015-05-31 23:49:42','admin','execute edit user admin success!',1,1,1),(29,'2015-06-01 00:14:26','admin','execute edit user admin success!',1,1,1),(30,'2015-06-01 00:14:41','admin','execute edit user admin success!',1,1,1),(31,'2015-06-01 00:14:50','admin','execute edit user admin success!',1,1,1),(32,'2015-06-01 00:15:50','admin','execute add user tanlong success!',1,2,1),(33,'2015-06-01 00:17:46','admin','execute edit user admin success!',1,1,1),(34,'2015-06-01 00:18:30','admin','execute edit user admin success!',1,1,1),(35,'2015-06-01 00:18:52','admin','execute edit user tanlong success!',1,2,1),(36,'2015-06-01 00:19:00','admin','execute edit user tanlong success!',1,2,1),(37,'2015-06-01 00:19:05','admin','execute edit user admin success!',1,1,1),(38,'2015-06-01 00:28:09','admin','execute logout user success!',0,NULL,1),(39,'2015-06-01 00:28:44','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(40,'2015-06-01 00:28:57','admin','execute logout user success!',0,NULL,1),(41,'2015-06-01 00:38:44','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(42,'2015-06-01 00:38:52','admin','execute edit user admin success!',1,1,1),(43,'2015-06-01 00:55:35','admin','execute edit user admin success!',1,1,1),(44,'2015-06-01 00:56:20','admin','execute edit user admin success!',1,1,1),(45,'2015-06-01 00:56:26','admin','execute edit user admin success!',1,1,1),(46,'2015-06-01 00:56:31','admin','execute edit user admin success!',1,1,1),(47,'2015-06-01 00:56:36','admin','execute edit user admin success!',1,1,1),(48,'2015-06-01 00:56:44','admin','execute edit user admin success!',1,1,1),(49,'2015-06-01 00:56:59','admin','execute edit user tanlong success!',1,2,1),(50,'2015-06-01 00:57:20','admin','execute add user t success!',1,3,1),(51,'2015-06-01 00:57:25','admin','execute edit user t success!',1,3,1),(52,'2015-06-01 00:57:44','admin','execute edit user tanlong success!',1,2,1),(53,'2015-06-01 00:57:51','admin','execute edit user tanlong success!',1,2,1),(54,'2015-06-01 00:57:58','admin','execute edit user tanlong success!',1,2,1),(55,'2015-06-01 06:11:15','admin','execute edit user t success!',1,3,1),(56,'2015-06-01 07:15:48','admin','execute edit user admin success!',1,1,1),(57,'2015-06-14 09:09:44','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(58,'2015-06-14 09:13:56','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(59,'2015-06-14 09:14:16','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(60,'2015-06-15 18:57:23','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(61,'2015-06-15 22:59:40','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(62,'2015-06-17 11:23:28','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(63,'2015-06-17 20:50:41','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(64,'2015-06-19 11:51:12','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(65,'2015-06-19 17:37:40','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(66,'2015-06-19 17:47:30','admin','execute edit user admin success!',1,1,1),(67,'2015-06-19 17:47:43','admin','execute edit user tanlong success!',1,2,1),(68,'2015-06-20 07:27:22','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(69,'2015-06-20 10:54:17','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(70,'2015-06-21 11:08:04','admin','execute edit permission productline_1_manage success!',1,1,1),(71,'2015-06-21 11:56:55','admin','execute logout user success!',0,NULL,1),(72,'2015-06-21 11:56:58','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(73,'2015-06-21 11:57:31','admin','execute logout user success!',0,NULL,1),(74,'2015-06-21 11:57:33','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(75,'2015-06-23 03:36:36','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(76,'2015-06-23 20:55:44','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(77,'2015-06-23 23:31:24','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1),(78,'2015-06-23 23:43:22','admin','execute login user:admin ip:127.0.0.1 success!',0,NULL,1);
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codename` varchar(64) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codename` (`codename`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'productline_1_manage','手浪工单管理权限',4),(2,'productline_2_manage','1产品线管理权限',4),(3,'productline_3_manage','手机新浪网-独立产品产品线管理权限',4),(4,'productline_4_manage','test3产品线管理权限',4);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_users`
--

DROP TABLE IF EXISTS `permission_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_id` (`permission_id`,`user_id`),
  CONSTRAINT `permission_users_permission_id_1a26b9f845a70663_fk_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_users`
--

LOCK TABLES `permission_users` WRITE;
/*!40000 ALTER TABLE `permission_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productname` varchar(64) NOT NULL,
  `productdesc` varchar(256) NOT NULL,
  `svnpath` varchar(256) NOT NULL,
  `rsyncpath` varchar(256) NOT NULL,
  `rsyncport` int(11) NOT NULL,
  `rsyncmodel` varchar(64) NOT NULL,
  `productline_id` int(11) NOT NULL,
  `laststable` varchar(256) DEFAULT NULL,
  `needsimu` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_productline_id_2d48bedd73def50_fk_productline_id` (`productline_id`),
  CONSTRAINT `product_productline_id_2d48bedd73def50_fk_productline_id` FOREIGN KEY (`productline_id`) REFERENCES `productline` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (2,'浪首接口','浪首接口','http://svn1.intra.sina.com.cn/wapcms/wap_remoulds/api/trunk','/wap_remould/api',8873,'wap_remould',1,NULL,0),(3,'2','2','2','2',2,'2',2,NULL,1),(4,'东风导弹','的','1','2',3,'4',1,NULL,1);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_onlineip`
--

DROP TABLE IF EXISTS `product_onlineip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_onlineip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `iplist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`iplist_id`),
  KEY `product_onlineip_iplist_id_490d1d050a48d99b_fk_iplist_id` (`iplist_id`),
  CONSTRAINT `product_onlineip_iplist_id_490d1d050a48d99b_fk_iplist_id` FOREIGN KEY (`iplist_id`) REFERENCES `iplist` (`id`),
  CONSTRAINT `product_onlineip_product_id_103be54e543e266a_fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_onlineip`
--

LOCK TABLES `product_onlineip` WRITE;
/*!40000 ALTER TABLE `product_onlineip` DISABLE KEYS */;
INSERT INTO `product_onlineip` VALUES (26,2,2),(24,3,4),(25,4,2),(3,13,2);
/*!40000 ALTER TABLE `product_onlineip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_simulationip`
--

DROP TABLE IF EXISTS `product_simulationip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_simulationip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `iplist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`iplist_id`),
  KEY `product_simulationip_iplist_id_4fab692a07c94ad3_fk_iplist_id` (`iplist_id`),
  CONSTRAINT `product_simulationip_iplist_id_4fab692a07c94ad3_fk_iplist_id` FOREIGN KEY (`iplist_id`) REFERENCES `iplist` (`id`),
  CONSTRAINT `product_simulationip_product_id_6b7578e7a525862_fk_product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_simulationip`
--

LOCK TABLES `product_simulationip` WRITE;
/*!40000 ALTER TABLE `product_simulationip` DISABLE KEYS */;
INSERT INTO `product_simulationip` VALUES (39,2,1),(37,3,3),(38,4,3),(1,9,1),(2,9,2),(3,9,3),(4,10,1),(5,10,2),(6,10,5),(7,11,1),(8,11,2),(9,11,3),(10,12,2),(11,12,3),(12,12,4),(15,13,4);
/*!40000 ALTER TABLE `product_simulationip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productline`
--

DROP TABLE IF EXISTS `productline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `desc` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productline`
--

LOCK TABLES `productline` WRITE;
/*!40000 ALTER TABLE `productline` DISABLE KEYS */;
INSERT INTO `productline` VALUES (1,'手机新浪网','手机新浪网'),(2,'1','2'),(3,'手机新浪网-独立产品','手机新浪网独立产品-上线频率高'),(4,'test3','11test');
/*!40000 ALTER TABLE `productline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productline_users`
--

DROP TABLE IF EXISTS `productline_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productline_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productline_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `productline_id` (`productline_id`,`user_id`),
  KEY `productline_users_user_id_646e6f8f7338934c_fk_auth_user_id` (`user_id`),
  CONSTRAINT `productline_us_productline_id_470e244edf08b3a1_fk_productline_id` FOREIGN KEY (`productline_id`) REFERENCES `productline` (`id`),
  CONSTRAINT `productline_users_user_id_646e6f8f7338934c_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productline_users`
--

LOCK TABLES `productline_users` WRITE;
/*!40000 ALTER TABLE `productline_users` DISABLE KEYS */;
INSERT INTO `productline_users` VALUES (10,1,1),(13,1,2),(11,2,1),(14,2,2),(15,3,2),(12,4,1),(16,4,2);
/*!40000 ALTER TABLE `productline_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `desc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'config_manage','系统配置管理'),(2,'user_manage','用户管理'),(3,'authority_manage','权限管理'),(4,'system_manage','系统管理'),(5,'developer','开发'),(6,'tester','测试'),(7,'productline_mange','产品线管理员');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_users`
--

DROP TABLE IF EXISTS `role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_users`
--

LOCK TABLES `role_users` WRITE;
/*!40000 ALTER TABLE `role_users` DISABLE KEYS */;
INSERT INTO `role_users` VALUES (146,1,1),(137,1,3),(147,2,1),(148,3,1),(149,4,1),(153,4,2),(150,5,1),(151,6,1),(152,7,1),(138,7,3);
/*!40000 ALTER TABLE `role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(128) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `realname` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `user_profile_user_id_42b77ab30a9bb3f0_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (1,'技术保障','4371','管理员',1),(2,'技术保障部','4371','谭龙',2),(3,'1','2','t',3);
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-06-24 10:20:09
