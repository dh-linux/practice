#!/usr/bin/env  python
# *-*coding:utf-8*-*
import smtplib
import logging
from email.mime.text import MIMEText
from config.models import Config
from product.models import Product

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

mailcontent = '''<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">


table,td,th {
	border: 0;
	padding: 0;
	margin: 0;
	border-collapse: collapse;
	font-size: 12px
}
body{
	font-family: 'Shojumaru',cursive,Arial,serif;
}

</style>
</head>
<body>
	<table style="width: 800px">
		<tbody>
			<tr>
				<td cellpadding="0" cellspacing="0" style="background: #005580; height: 50px; border: 1px solid #005580; " colspan="3">
					<h1 style="margin: 0 0 0 30px">
						<a href="http://aos.wap.sina.cn/" style="font-size: 26px; text-decoration: none; color: #FFF" target="_blank">AOS系统通知</a>
					</h1>
				</td>
			</tr>
			<tr>
				<td colspan="3" style="border: 1px solid #005580; padding: 10px">
					<div style="text-indent: 2em; margin: 0px">
						<style type="text/css">
						
						
						td {
							border: solid 1px #005580;
							padding-left: 10px
						}
						
						.STYLE18 {
							font-size: 13px;
							font-weight: bold;
							line-height: 25px
						}
						
						.STYLE19 {
							font-size: 13px
						}
						
						.STYLE20 {
							font-size: 14px;
							font-weight: bold
						}
					
						
						</style>
						<table cellspacing="0" style="border: solid 1px #005580; border-collapse: collapse;width:100%%">
							<thead>
						    	<tr>
						      		<th colspan="4" bgcolor="dddddd"><span class="STYLE18">通知详情</span></th>
						    	</tr>
						  	</thead>
							<tbody>
								<tr>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">通知内容:</span>
									</td>
									<td colspan="3">
										<div class="rows STYLE19">
										<label target="_blank">%s</label>
										</div>
									</td>
								</tr>
										</tbody>
							<thead>
						    	<tr>
						      		<th colspan="4" bgcolor="dddddd"><span class="STYLE18">提案概要</span></th>
						    	</tr>
						  	</thead>
							<tbody>
								<tr>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">提案标题:</span>
									</td>
									<td colspan="3">
										<div class="rows STYLE19">
										<label target="_blank">%s</label>
										</div>
									</td>
								</tr>
								
								<tr>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">创建人: </span>
									</td>
									<td width="200" nowrap="nowrap">
										<span class="STYLE19">%s</span>
									</td>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">测试人: </span>
									</td>
									<td>
										<span class="STYLE19">%s</span>
									</td>
								</tr>
										
								<tr>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">提案状态: </span>
									</td>
									<td width="200" nowrap="nowrap">
										<span class="STYLE19">%s</span>
									</td>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">提案ID: </span>
									</td>
									<td>
										<span class="STYLE19">%s</span>
									</td>
								</tr>
								
										
								<tr>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">创建时间: </span>
									</td>
									<td width="200" nowrap="nowrap">
										<span class="rows STYLE19">%s</span>
									</td>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">更新时间: </span>
									</td>
									<td>
										<span class="rows STYLE19">%s</span>
									</td>
								</tr>
								<tr>
									<td width="150" bgcolor="dddddd" nowrap="nowrap">
										<span class="STYLE18">提案详情: </span>
									</td>
									<td colspan="3">
										<span class="rows STYLE19">
										<a href="http://aos.wap.sina.cn" target="_blank">http://aos.wap.sina.cn</a>
										</span>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="3" style="background: #005580; height: 50px; border: 1px solid #005580; text-align: center">
					<p style="margin: 0; font-size: 18px; color: #FFF">
						<strong style="color: #FFF;">
						服务支持
						<strong style="color: #FEEC52;">mop@staff.sina.com.cn</strong>
					</p>
				</td>
			</tr>
		</tbody>
	</table>
</body>
</html>
'''

status = {'0': '未处理', '1': '仿真上线中', '2': '仿真完毕', '3':'仿真上线成功', '4':'已批准正式上线', '5': '正式上线中', '6':'正式上线完毕', '7':'提案执行成功', '-1': '提案失败'}

# 发送邮件
def send_mail(issue):
    product = Product.objects.get(id = issue.product_name_id)
    if issue.status == 0:
        sub = "%s创建了[%s]上线提案" % (issue.create_user, product.productname)
        tostr = "%s@staff.sina.com.cn" % (issue.create_user)
        to = ["%s@staff.sina.com.cn" % (issue.create_user), "mop@staff.sina.com.cn"]
    elif issue.status == 1:
        sub = "aos机器人受理了[%s]仿真上线" % (product.productname)
        tostr = "mop@staff.sina.com.cn"
        to = ["mop@staff.sina.com.cn"]

    elif issue.status == 2:
        sub = "[%s]仿真已完成,请测试" % (product.productname)
        tostr = "%s@staff.sina.com.cn, %s@staff.sina.com.cn" % (issue.test_user, issue.create_user)
        to = ["%s@staff.sina.com.cn" % issue.test_user, "%s@staff.sina.com.cn" % issue.create_user, "mop@staff.sina.com.cn"]
    elif issue.status == 3:
        sub = "%s提交了[%s]上线申请,请审批" % (issue.create_user, product.productname)
        tostr = "%s@staff.sina.com.cn" % (issue.assign_user)
	to = ["%s@staff.sina.com.cn" % issue.assign_user, " %s@staff.sina.com.cn" % issue.create_user, "mop@staff.sina.com.cn"]
    elif issue.status == 4:
        sub = "%s通过了[%s]上线审批,请mop确认" % ( issue.product_name.productline.admin, product.productname)
        tostr = "%s@staff.sina.com.cn" % (issue.create_user)
        to = ["%s@staff.sina.com.cn" % (issue.create_user), "mop@staff.sina.com.cn"]
    elif issue.status == 5:
        sub = "mop通过了[%s]正式上线申请" % (product.productname)
        tostr = "%s@staff.sina.com.cn" % issue.create_user
        to = ["%s@staff.sina.com.cn" % issue.create_user, "mop@staff.sina.com.cn"]
    elif issue.status == 6:
        sub = "机器人受理了[%s]正式上线" % (product.productname)
        tostr = "mop@staff.sina.com.cn"
        to = ["mop@staff.sina.com.cn"]
    elif issue.status == 7:
        sub = "[%s]正式上线已完成,请测试确认" % (product.productname)
        tostr = "%s@staff.sina.com.cn, %s@staff.sina.com.cn" %(issue.test_user, issue.create_user)
        to = ["%s@staff.sina.com.cn" % issue.test_user, "%s@staff.sina.com.cn" % issue.create_user, "mop@staff.sina.com.cn"]
    elif issue.status == 8:
        sub = "%s确认了[%s]正式上线成功" % (issue.test_user, product.productname)
        tostr = "%s@staff.sina.com.cn, %s@staff.sina.com.cn" % (issue.create_user, issue.test_user)
        to = ["%s@staff.sina.com.cn" % issue.create_user,  "%s@staff.sina.com.cn" % issue.test_user, "mop@staff.sina.com.cn"]
    else :
        sub = "[%s]上线失败" % (product.productname)
        tostr = "%s@staff.sina.com.cn, %s@staff.sina.com.cn" % (issue.create_user, issue.test_user)
        to = ["%s@staff.sina.com.cn" % issue.create_user, "%s@staff.sina.com.cn"  % issue.test_user, "mop@staff.sina.com.cn"]
    logger = logging.getLogger('django.notify')
    try:
        config = Config.objects.get(id = 1)
        mailserver = config.mailserver
        mailport = config.mailport
        mailuser = config.mailuser
        mailpasswd = config.mailpasswd
    except Exception,e:
        logger.error(u'邮件发送失败:' + str(e))
    try:
        status_str = status[issue.status]
    except:
        status_str = '处理中'
    content = mailcontent % (sub, issue.issue_title, issue.create_user, issue.test_user, status_str, issue.id, issue.createdate, issue.lastupdate )
    msg = MIMEText(content, _subtype='html', _charset='utf-8')
    msg['From'] = 'aos@staff.sina.com.cn'
    msg['Subject'] = sub
    msg['To'] = tostr 
    #msg['Cc'] = 'mop@staff.sina.com.cn'
    
    agent_from = "<" + mailuser + ">"
    
    try:
        server = smtplib.SMTP()
        server.connect(mailserver, int(mailport))
		#server.ehlo()
        #server.starttls()
        server.login(mailuser, mailpasswd)
        server.sendmail(agent_from, to, msg.as_string())
        server.quit()
    except Exception, e:
        logger.error(u'邮件发送失败:' + str(e))
        
