# -*- coding:utf-8 -*-

from django.http import HttpResponse, HttpResponseBadRequest
from issue.models import Issue, Product
from config.models import Config
from mail import send_mail
import django_rq

import os,subprocess
import time
import re

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

#code_path         = r'/data1/sinawap/aoscode/'
#dpool_test_server = r'10.13.1.233'
#iplsit = dpool_test_server
#dpool_code_path   = r'/data1/sinawap/aoscode/dpool/'

def code_issue(product, issue):

    productid    = product.id
    productname  = product.productname
    productline  = product.productline.name
    admin        = product.productline.admin
    svnpath      = product.svnpath
    rsyncpath    = product.rsyncpath
    rsyncport    = str(product.rsyncport)
    rsyncmodel   = product.rsyncmodel
    status = issue.status
    code_version = 0
    if not issue.msg:
        issue.msg = ''
    try:
        config = Config.objects.get(id = 1)
        svnuser = config.svnuser
        svnpasswd = config.svnpasswd
        codepath = config.codepath
    except Exception,e :
        issue.msg += str(e)
        issue.status = -1
        issue.save()
        return 
    #机器人拿到提案后，将提案状态设置为 上线中， 并加提案分配给自己.
    status       = int(issue.status) + 1
    issue.status = status 
    issue.assign_user = 'aos上线机器人'
    issue.save()
    
    queue_high = django_rq.get_queue('high')
    queue_high.enqueue(send_mail, issue)
    
    product_code_path = os.path.join(codepath, productline, productname)
    product_code_path += '/'
    #print product_code_path

    if not os.path.isdir(product_code_path):
        os.makedirs(product_code_path)

    export_cmd = 'svn export --username ' + svnuser + ' --password ' + svnpasswd + ' ' + svnpath + '/ ' + product_code_path + ' --force'
    #print export_cmd
    #issue.msg += "代码正在拉取..."
    svnexport = subprocess.Popen(export_cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
    #print svnexport
    svnexport_stdout, svnexport_stderr = svnexport.communicate()
    if svnexport_stderr:
        issue.msg += "<font color=\"red\">" + svnexport_stderr + "</font>"
        issue.status = -1
        issue.save()
    	queue_high = django_rq.get_queue('high')
    	queue_high.enqueue(send_mail, issue)
	return
    info_cmd = 'svn --username ' + svnuser + ' --password ' + svnpasswd + ' info ' + svnpath
    svninfo = subprocess.Popen(info_cmd, stdout = subprocess.PIPE, stderr = subprocess.PIPE, shell = True)
    #print svninfo
    svninfo_stdout, svninfo_stderr = svninfo.communicate()
    if svninfo_stderr:
        issue.msg += "<font color=\"red\">" + svninfo_stderr + "</font>"
	issue.status = -1
        issue.save()
    	queue_high = django_rq.get_queue('high')
    	queue_high.enqueue(send_mail, issue)
	return
    else:
        try:
            code_version = re.findall("Revision:(.*)\n", svninfo_stdout)[0]
        except Exception, e:
            code_version = 0
            issue.msg += str(e)
	    issue.status = -1
            issue.save()
            queue_high = django_rq.get_queue('high')
            queue_high.enqueue(send_mail, issue)
        issue.code_version = code_version
        issue.save()
    
    if issue.status == 1:
        simu_ips = product.simulationip.all()
        simulation = []
        for simu in simu_ips:
            iplist = simu.iplist
            ips = iplist.split('\n')
            for ip in ips:
                simulation.append(ip)
        iplist = set(simulation)
    else:
        onli_ips = product.onlineip.all()
        online = []
        for onli in onli_ips:
            iplist = onli.iplist
            ips = iplist.split('\n')
            for ip in ips:
                online.append(ip)
        iplist = set(online)
    #print 'iplist ', iplist
    if issue.status == 1:
        issue.msg += '<h3>仿真上线</h3>'
    else:
        issue.msg += '<h3>正式上线</h3>'
    print iplist
    for ip in iplist:
	ip = ip.strip()
	if ip and '\r' not in ip and '\t' not in ip and ' ' not in ip:
            rsync_cmd = 'rsync -avz --delete-after --exclude "sinasrv_config" --timeout=15 --contimeout=10 ' + '--port=' + rsyncport + ' ' + product_code_path + ' ' + ip + '::' + rsyncpath
            print "rsync_cmd", rsync_cmd
	    rsync = subprocess.Popen(rsync_cmd, stdout = subprocess.PIPE, stderr = subprocess.PIPE, shell = True)
            rsync_stdout, rsync_stderr = rsync.communicate()
            if rsync_stderr:
                print "rsync stderr", rsync_stderr
                issue.msg += "<font color=\"red\">" + ip + ':' + rsync_stderr + "</font>"
            else:
                issue.msg +=  '''%s ... ok\n''' % ip
	        print issue.msg
	        #issue.msg += '<h4>' + ip + '</h4>\n' + rsync_stdout
            issue.save()
    #上线成功后修改提案信息，并将提案分配给测试者
    #print 'status ', issue.status
    issue.status = status + 1
    #print 'status ', issue.status
    issue.assign_user = issue.test_user
    issue.save()
    
    queue_high = django_rq.get_queue('high')
    queue_high.enqueue(send_mail, issue)
    
    product.laststable = code_version
    product.save()
    #print 'Process finished...'
