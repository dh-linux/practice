from django.conf.urls import patterns
from django.conf.urls import url

urlpatterns = patterns('',
    url(r'^$', 'issue.views.index',name="issue"),
    url(r'^index/$', 'issue.views.search', name="issue_index"),
    url(r'^changestatus/$', 'issue.views.changestatus', name="issue_changestatus"),
    url(r'^search/$', 'issue.views.search', name="issue_search"),
    url(r'^add/$', 'issue.views.add',name="issue_add"),
    url(r'^show/(?P<id>\d+)/$', 'issue.views.show', name="issue_show"),
    url(r'^myissue/$', 'issue.views.myissue', name="issue_myissue"),
    url(r'^mysubmit/$', 'issue.views.mysubmit', name="issue_mysubmit"),
    url(r'^myhistory/$', 'issue.views.myhistory', name="issue_myhistory"),

)
