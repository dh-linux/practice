#-*- coding:utf-8 -*-
from django.db import models
from product.models import Product

class Issue(models.Model):
    class Meta:
        db_table = "issue"
    rt_id           = models.IntegerField(null=True, blank=True)
    rt_status       = models.CharField(max_length=64,null=True,blank=True)
    issue_title        = models.CharField(max_length=256)
    issue_content      = models.TextField(null=True,blank=True)
    lock            = models.CharField(default=True,choices=(('False','unlock'),('True','lock')),max_length=32)
    
    product_name    = models.ForeignKey(Product)

    environment     = models.CharField(max_length=32,null=True,blank=True)
    create_user     = models.CharField(max_length=32,null=True,blank=True)
    test_user       = models.CharField(max_length=32,null=True,blank=True)
    assign_user     = models.CharField(max_length=32,null=True,blank=True)
    createdate      = models.DateTimeField(auto_now_add=True)
    lastupdate      = models.DateTimeField(auto_now=True)
    status          = models.IntegerField(default = 0)    
    msg             = models.TextField(null=True,blank=True)
    info            = models.TextField(null=True,blank=True)
    code_version    = models.IntegerField(null=True,blank=True)
    
    def __unicode__(self):
        return self.issue_title

