# -*- coding:utf-8 -*-
from django.http import HttpResponse, HttpResponseBadRequest
from issue.models import Issue, Product
import os,subprocess

svn_username      = r'denghao1'
svn_password      = r'dh.123123'

code_path         = r'/data1/aos/code/'
dpool_test_server = r'10.13.1.233'
dpool_code_path   = r'/data1/aos/code/dpool/'

def code(request):
    global svn_username, svn_password, code_path, dpool_test_server, dpool_code_path
    if request.POST:
        product_line    = request.POST.get('product_line').strip()
        product_name    = request.POST.get('product_name').strip()
        environment     = request.POST.get('environment').strip()

        p               = product.objects.get(product_name=product_name)
        svn_path        = p.svn_path
        rsync_path      = p.rsync_path
        rsync_port      = str(p.rsync_port)
        rsync_model     = p.rsync_model

        product_code_path       = code_path + product_line + '/' + product_name

        if not os.path.isdir(product_code_path):
            os.makedirs(product_code_path)

        svn = 'svn export --username ' + svn_username + ' --password ' + svn_password + ' ' + svn_path + '/ ' + product_code_path + ' --force'
        svn_result = subprocess.Popen(svn,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        status = svn_result.communicate()[1]
        if status != '':
            return HttpResponse('svn co has some problem ! :( ')
        
        # 路径后面要加上 / , 不然rsync路径会有问题
        dpool_code_path = dpool_code_path + product_name + '/'

        if environment == u'仿真环境':
            rsync = 'rsync -avz --delete --exclude "sinasrv_config" --timeout=15 --contimeout=10 ' + '--port=' + rsync_port + ' ' + dpool_code_path + ' ' + dpool_test_server + '::' + rsync_model + '/' +rsync_path
            rsync_result = subprocess.Popen(rsync,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
            status = rsync_result.communicate()[1]
            if status != '':
                return HttpResponse('rsync has some problem ! :(')
