#-*- coding:utf-8 -*-
from django.shortcuts import render, render_to_response, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect, HttpResponseBadRequest
from django.db.models import Q
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.template import RequestContext
from django.contrib.auth.models import User

from account.models import User, getUser
from issue.models import Issue
from product.models import Product
from productline.models import Productline

from utils.code import code_issue
from utils.mail import send_mail

import simplejson
import django_rq
before = 3
after = 3
def index(request):
    return render_to_response('issue/index.html',{})

def search(request):
    #checkundealed()
    user = getUser(request.user.id)
    print user.roles_desc
    try:
        issue_list = Issue.objects.order_by('-id')
        if 'query' in request.POST and request.POST['query']:
            query = request.POST['query'].strip()
	    try:
                query = int(query)
                issue_list = Issue.objects.filter(id__icontains=query)
            except:
                issue_list = Issue.objects.filter(product_name__productname__icontains=query).order_by('-id')

        paginator = Paginator(issue_list, 10)
        currentPage = int(request.POST.get('pageNum', 1))
        try:
            pager = paginator.page(currentPage)
        except InvalidPage:
            pager = paginator.page(1)
        lastPage = paginator.page_range[-1]
        if currentPage >= after:
            page_range = paginator.page_range[currentPage - after : currentPage + before]
        else:
            page_range = paginator.page_range[0 : currentPage + before]
        return render_to_response('issue/search.html', {'issue_list':pager, 'user':user, 'url': '/issue/search/', 'page_range': page_range, 'last_page':lastPage})
    except Exception,e:
        print e
        return  HttpResponseBadRequest("Bad Request!")

def assigned(request):
    user = getUser(request.user.id)
    if request.POST:
        issue_list = Issue.objects.filter(assigned=user.username).order_by('-id')

        if 'query' in request.POST and request.POST['query']:
            query = request.POST['query'].strip()
            #print query,rt_list
            issue_list = Issue.objects.filter(id__icontains=query)

        paginator = Paginator(issue_list, 10)
        currentPage = int(request.POST.get('pageNum', 1))
        try:
            pager = paginator.page(currentPage)
        except InvalidPage:
            pager = paginator.page(1)
        lastPage = paginator.page_range[-1]
        if currentPage >= after:
            page_range = paginator.page_range[currentPage - after : currentPage + before]
        else:
            page_range = paginator.page_range[0 : currentPage + before] 
        return render_to_response('issue/search.html', {'issue_list':pager, 'user':user, 'url': '/issue/assigned/', 'page_range': page_range, 'last_page': lastPage})
    else:
        return  HttpResponseBadRequest("Bad Request!")


def add(request):
    productline_list = request.user.productline_set.all()
    user_list = User.objects.all()
    if request.POST:
        issue_title        = request.POST.get('issue_title').strip()
        product_line       = request.POST.get('productline_name').strip()
        product_name_id    = request.POST.get('product_name').strip()
        issue_content      = request.POST.get('issue_content').strip()
        test_user          = request.POST.get('test_user').strip()
        create_user        = request.user.username

        # change product_name from string to model instance
        product_instance       = Product.objects.get(id=product_name_id)
        issue                  = Issue()
        if product_instance.needsimu == 0:
            issue.status       = 3
	    issue.assign_user  = product_instance.productline.admin
        else:
            issue.status       = 0
	    issue.assign_user  = create_user
        issue.issue_title      = issue_title
        issue.product_name     = product_instance
        issue.issue_content    = issue_content
        issue.create_user      = create_user
        issue.test_user        = test_user
        issue.lock             = 'unLock'




        issue.save() 

        p                      = Product.objects.get(id=product_name_id)
	
	queue_high = django_rq.get_queue('high')
    	queue_high.enqueue(send_mail, issue)
	if issue.status == 0:
            queue_default = django_rq.get_queue('default')
            queue_default.enqueue(code_issue, p, issue)

        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/issue/index", "message":u'提案创建成功'}), content_type='application/json')
    return render_to_response('issue/add.html',{'productline_list':productline_list, 'user_list': user_list},context_instance=RequestContext(request))

def show(request, id):
    show_issue = Issue.objects.get(id=id)
    return render_to_response('issue/show.html', {'show_rt':show_issue, 'url': '/issue/show/'})


def changestatus(request):
    if request.POST:
        issueid = request.POST.get("issueid").strip()
        result = request.POST.get("result").strip()
        issue = Issue.objects.get(id = issueid)
	#queue_high = django_rq.get_queue('high')
	#queue_high.enqueue(send_mail, issue)
        if result == "1":
            test_user = issue.test_user
            create_user = issue.create_user
            status = int(issue.status)
            issue.status = status + 1
	    if issue.status == 8:
                issue.assign_user = create_user
            elif issue.status == 3:
                p = issue.product_name
		admin = p.productline.admin
	    	issue.assign_user = admin
	    elif issue.status == 4:
                issue.assign_user = 'mop'
            else:
                issue.assign_user = test_user
            issue.save()
            print 'statusis', status + 1
            if status + 1 == 5:
                p = issue.product_name
                queue_default = django_rq.get_queue('default')
                queue_default.enqueue(code_issue, p, issue)
        else:
            create_user = issue.create_user
            issue.status = -1
            issue.assign_user = create_user
            issue.save()
	queue_high = django_rq.get_queue('high')
	queue_high.enqueue(send_mail, issue)
        
    return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/issue/index", "message":u'提案创建成功'}), content_type='application/json')

def myissue(request):
    user = getUser(request.user.id)
    if request:
        issue_list = Issue.objects.filter(Q(assign_user=user.username), ~Q(status=8), ~Q(status=-1)).order_by('-id')

        if 'query' in request.POST and request.POST['query']:
            query = request.POST['query'].strip()
            issue_list = Issue.objects.filter(id__icontains=query)

        paginator = Paginator(issue_list, 10)
        currentPage = int(request.POST.get('pageNum', 1))
        try:
            pager = paginator.page(currentPage)
        except InvalidPage:
            pager = paginator.page(1)
        lastPage = paginator.page_range[-1]
        if currentPage >= after:
            page_range = paginator.page_range[currentPage - after : currentPage + before]
        else:
            page_range = paginator.page_range[0 : currentPage + before]
        return render_to_response('issue/search.html', {'issue_list':pager, 'user':user, 'url':'/issue/myissue/', 'page_range':page_range, 'last_page': lastPage})
    else:
        return  HttpResponseBadRequest("Bad Request!")

def mysubmit(request):
    user = getUser(request.user.id)
    if request:
        issue_list = Issue.objects.filter(Q(create_user=user.username), ~Q(status=8), ~Q(status=-1)).order_by('-id')

        if 'query' in request.POST and request.POST['query']:
            query = request.POST['query'].strip()
            issue_list = Issue.objects.filter(id__icontains=query)

        paginator = Paginator(issue_list, 10)
        currentPage = int(request.POST.get('pageNum', 1))
        try:
            pager = paginator.page(currentPage)
        except InvalidPage:
            pager = paginator.page(1)
        lastPage = paginator.page_range[-1]
        if currentPage >= after:
             page_range = paginator.page_range[currentPage - after : currentPage + before]
        else:
             page_range = paginator.page_range[0 : currentPage + before]
        return render_to_response('issue/search.html', {'issue_list':pager, 'user':user, 'url': '/issue/mysubmit/', 'page_range': page_range, 'last_page': lastPage})
    else:
        return  HttpResponseBadRequest("Bad Request!")

def myhistory(request):
    user = getUser(request.user.id)
    if request:
        issue_list = Issue.objects.filter(create_user=user.username).order_by('-id')

        if 'query' in request.POST and request.POST['query']:
            query = request.POST['query'].strip()
            issue_list = Issue.objects.filter(id__icontains=query)

        paginator = Paginator(issue_list, 10)
        currentPage = request.POST.get('pageNum', 1)
        try:
            pager = paginator.page(currentPage)
        except InvalidPage:
            pager = paginator.page(1)
        lastPage = paginator.page_range[-1]
        if currentPage >= after:
            page_range = paginator.page_range[currentPage - after : currentPage + before]
        else:
            page_range = paginator.page_range[0 : currentPage + before]
        return render_to_response('issue/search.html', {'issue_list':pager, 'user':user, 'url': '/issue/myhistory/', 'page_range': page_range, 'last_page': lastPage})
    else:
        return  HttpResponseBadRequest("Bad Request!")




def checkundealed():
    issue_list = Issue.objects.filter(status=0).order_by('-id')
    for issue in issue_list:
        p = issue.product_name
        queue = django_rq.get_queue('high')
        queue.enqueue(code_issue, p, issue)





def gettestuser(request, productline_id):
    testuser = []
    user_list = User.objects.all()
    for user in user_list:
        roles = user.role_set()
    try:
        products = Product.objects.filter(productline_id = productline_id)
        product_list = {}
        for item in products:
            product_list[item.id] = item.productname
    except:
        return HttpResponse(simplejson.dumps({"status":"0", "product_list": product_list}), content_type = 'application/json')
    return HttpResponse(simplejson.dumps({"status":"1", "product_list":product_list}), content_type = 'application/json')

