# -*- coding:utf-8 -*-

# django library
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect,HttpResponseBadRequest
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login as auth_login ,logout as auth_logout
from django.utils.translation import ugettext_lazy as _
import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.contrib.auth.decorators import login_required


# our own code
from config.models import Config
from authority.decorators import permission_required

@permission_required('config_manage')
def index(request):
    try:
        config = Config.objects.get(id = 1)
    except:
        config = Config()
        config.svnuser = ''
        config.svnpasswd = ''
        config.codepath = ''
        config.mailserver = ''
        config.mailport = ''
        config.mailuser = ''
        config.mailpasswd = ''
        config.save()
    if request.POST:
        svnuser = request.POST.get("svnuser")
        svnpasswd = request.POST.get("svnpasswd")
        codepath = request.POST.get("codepath")
        mailserver = request.POST.get("mailserver")
        mailport = request.POST.get("mailport")
        mailuser = request.POST.get("mailuser")
        mailpasswd = request.POST.get("mailpasswd")
        #　保存区域信息
        config = Config.objects.get(id=1);
        config.svnuser = svnuser
        config.svnpasswd = svnpasswd
        config.codepath = codepath
        config.mailserver = mailserver
        config.mailport = mailport
        config.mailuser = mailuser
        config.mailpasswd = mailpasswd
        config.save()
        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/config/index", "message":u'修改成功'}), content_type='application/json')
    return render_to_response('config/index.html', {'config':config})
