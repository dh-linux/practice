#!usr/bin/env python
#coding: utf-8
from django.conf.urls import patterns
from django.conf.urls import url

urlpatterns = patterns('',
    url(r'^$', 'config.views.index',name="config"),
    url(r'^index/$', 'config.views.index', name="config_index"),
)
