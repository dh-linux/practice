# -*- coding:utf-8 -*-
from django.db import models

# our own code


class Config(models.Model):
    # 重新定义表名
    class Meta:
        db_table = 'config'
    svnuser = models.CharField(max_length=32, null = True, blank = True) 
    svnpasswd = models.CharField(max_length=32, null = True, blank = True) 
    codepath = models.CharField(max_length=256, null = True, blank = True) 
    mailserver = models.CharField(max_length=64, null = True, blank = True) 
    mailport = models.CharField(max_length=32, null = True, blank=True) 
    mailuser = models.CharField(max_length=32, null = True, blank=True) 
    mailpasswd = models.CharField(max_length=32, null = True, blank=True) 


