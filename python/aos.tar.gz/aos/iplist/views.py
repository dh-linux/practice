# -*- coding:utf-8 -*-

# django library
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect,HttpResponseBadRequest
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login as auth_login ,logout as auth_logout
from django.utils.translation import ugettext_lazy as _
import simplejson
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.contrib.auth.decorators import login_required


# our own code
from iplist.models import Iplist
from authority.decorators import permission_required


@permission_required('config_manage')
def index(request):
    items = Iplist.objects.all()
    paginator = Paginator(items, 3)
    currentPage = int(request.POST.get('pageNum', 1))
    try:
        pager = paginator.page(currentPage)
    except InvalidPage:
        pager = paginator.page(1)
    after = 3
    before = 3
    lastPage = paginator.page_range[-1]
    if currentPage >= after:
	page_range = paginator.page_range[currentPage - after : currentPage + before]
    else:
        page_range = paginator.page_range[0 : currentPage + before]
    return render_to_response('iplist/index.html',{'iplist_list':pager, 'page_range':page_range, 'last_page': lastPage}, context_instance=RequestContext(request))
    
@permission_required('config_manage')
def add(request):
    if request.POST:
        groupname = request.POST.get("groupname")
        iplist_text = request.POST.get("iplist") 
        iplist = Iplist();
        iplist.groupname = groupname
        iplist.iplist = iplist_text
        iplist.save()
        
        
        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/iplist/index", "message":u'添加成功'}), content_type='application/json')
    return render_to_response('iplist/add.html')

@permission_required('config_manage') 
def edit(request, iplist_id):
    iplist = None
    try:
        iplist = Iplist.objects.get(id=int(iplist_id))
    except BaseException:
        return HttpResponse(simplejson.dumps({"statusCode":400, "message":u'ip分组不存在!'}), content_type='application/json')
    if request.POST:
        iplist.groupname = request.POST.get('groupname')
        iplist.iplist = request.POST.get('iplist')
        iplist.save()

        return HttpResponse(simplejson.dumps({"statusCode":200,"url": "/iplist/index", "message":u'编辑成功'}), content_type='application/json')
    return render_to_response('iplist/edit.html', {'iplist':iplist}) 


