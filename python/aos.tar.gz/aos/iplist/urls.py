#!usr/bin/env python
#coding: utf-8
from django.conf.urls import patterns
from django.conf.urls import url

urlpatterns = patterns('',
    url(r'^$', 'iplist.views.index',name="iplist"),
    url(r'^index/$', 'iplist.views.index', name="iplist_index"),
    url(r'^add/$', 'iplist.views.add',name="iplist_add"),
    url(r'^edit/(?P<iplist_id>\d+)/$', 'iplist.views.edit',name="iplist_edit"),
)
