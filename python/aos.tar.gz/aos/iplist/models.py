# -*- coding:utf-8 -*-
from django.db import models

# our own code


class Iplist(models.Model):
    # 重新定义表名
    class Meta:
        db_table = 'iplist'
    # 主键由Django生成
    # 名称
    groupname = models.CharField(max_length=32)
    iplist = models.TextField()
    


