# -*- coding:utf-8 -*-
# django library
from django.db import models
from django.contrib.auth.models import User
from django.db import connection
from django.contrib.sessions.models import Session

#our own code
import ldap
from role.models import Role
from productline.models import Productline
from authority.models import Permission

class UserProfile(models.Model):
    #重新定义表名
    class Meta:
        db_table = 'user_profile'
    # 用户对象，使用django 默认User对象
    user = models.OneToOneField(User)
    # 部门
    department = models.CharField(max_length=128, blank=True)
    # 电话
    phone = models.CharField(max_length=15, blank=True)
    # 真实姓名
    realname = models.CharField(max_length=32)
    
# 仅用于页面显示
class UserExtend():
    def __init__(self):
        # 序号
        self.id = None
        # 用户名
        self.username = None
        # 电子邮件
        self.email = None
        # 角色
        self.roles = None
        # 角色ID 列表
        self.role_ids = None
        # 产品线
        self.productlines = None
        #产品线ID列表
        self.productline_ids = None
        # 部门 
        self.department = None
        # 联系方式
        self.phone = None
        # 真实姓名
        self.realname = None
   
def user2Extend(users):
    user_list = []
    for item in users:
        user_list.append(getUser(item.id))
    return user_list

# 获取用户
def getUser(user_id):
    auth_user = User.objects.get(id=user_id)
    if not auth_user:
        return None
    user = UserExtend()
    user.id = auth_user.id
    user.username = auth_user.username
    user.email = auth_user.email
    user.department = auth_user.userprofile.department 
    user.phone = auth_user.userprofile.phone
    user.realname = auth_user.userprofile.realname
   
    role_list = auth_user.role_set.all()
    user.roles = ",".join([item.name for item in role_list])
    user.roles_desc = ",".join([item.name for item in role_list])
    user.role_ids = [item.id for item in role_list]

    productline_list = auth_user.productline_set.all()
    user.productlines = ",".join([item.name for item in productline_list])
    user.productline_ids = [item.id for item in productline_list]
    
    return user

def ldapAuth(user, passwd):
    if user == 'admin':
        return True
    if "@staff" not in user:
        user = user + "@staff.sina.com.cn"
    ldap_conn = ldap.initialize("ldap://10.210.97.21:389")
    ldap_conn.set_option(ldap.OPT_REFERRALS, 0)
    try:
        ldap_conn.simple_bind_s(user, passwd)

    except ldap.INVALID_CREDENTIALS:
        return False
    return True

def ldapLookup( user):
    try:
        ldap_conn = ldap.initialize("ldap://10.210.97.21:389")
        ldap_conn.set_option(ldap.OPT_REFERRALS, 0)
        ldap_conn.simple_bind_s("cn=adrdpm,ou=ldap,OU=adminaccount,dc=staff,dc=sina,dc=com,dc=cn", "er)aJkQQJ22-6.i")
        retrieveAttributes = ["mail", "telephoneNumber", "mobile", "telephoneNumber", "name"]
        #retrieveAttributes = ['*']
        find_object = "userPrincipalName=%s@staff.sina.com.cn" % (user)
        res = ldap_conn.search_s("dc=staff,dc=sina,dc=com,dc=cn", ldap.SCOPE_SUBTREE, find_object, retrieveAttributes)

        result = {}
        try:
            #print res[0]
            r = res[0][0].split(',')[:-6]
            result['department'] = '-'.join([i.split("=")[1] for i in r[1:]][::-1])
        except:
            result['department'] = ""
        try:
            result['name'] = res[0][1]["name"][0]
        except:
            result['name'] = "Not found"


        try:
            result['mail'] = res[0][1]["mail"][0]
        except:
            result['mail'] = ""

        try:
            result['phone'] = res[0][1]["mobile"][0]
        except:
            result['phone'] = ""
        try:
            result['telephone'] = res[0][1]["telephoneNumber"][0]
        except:
            result['telephone'] = ""
        
        for k,v in result.items():
            print k,v
        return result

    except Exception,e:
        return "No such user"
